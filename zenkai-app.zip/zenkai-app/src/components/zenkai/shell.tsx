import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutGrid, LayoutPanelLeft, MessageSquare, Monitor, SquareTerminal, Sparkles } from "lucide-react";
import { useZ } from "@/lib/zenkai";

// Five primary tabs. Files, Code, Settings and everything else live under Tools.
const TABS = [
  { to: "/", label: "Chat", Icon: MessageSquare, match: ["/"] },
  { to: "/workspace", label: "Workspace", Icon: LayoutPanelLeft, match: ["/workspace", "/code"] },
  { to: "/preview", label: "Preview", Icon: Monitor, match: ["/preview"] },
  { to: "/shell", label: "Shell", Icon: SquareTerminal, match: ["/shell"] },
  { to: "/tools", label: "Tools", Icon: LayoutGrid, match: ["/tools", "/files", "/settings"] },
] as const;

const TITLES: Record<string, string> = { "/code": "Code", "/files": "Files", "/settings": "Settings" };

export function AppShell({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { busy } = useZ();
  const title = TABS.find((t) => (t.match as readonly string[]).includes(path))?.label ?? "ZENKAI";
  const sub = TITLES[path] ?? (path === "/" ? null : title);
  return (
    <div className="flex h-dvh w-full flex-col bg-background">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b px-4">
        <div className={`bg-brand flex h-8 w-8 items-center justify-center rounded-xl shadow-[0_0_18px_-2px_var(--glow-1)] ${busy ? "animate-pulse" : ""}`}>
          <Sparkles className="h-4 w-4 text-primary-foreground" />
        </div>
        <span className="text-base font-semibold tracking-tight">ZENKAI</span>
        {sub && <span key={sub} className="animate-rise text-sm text-muted-foreground">/ {sub}</span>}
        {busy && <span className="ml-auto flex items-center gap-1.5 text-xs text-muted-foreground"><span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-primary" />Working</span>}
      </header>
      <main key={path} className="animate-rise flex min-h-0 flex-1 flex-col">{children}</main>
      <nav className="flex shrink-0 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
        {TABS.map(({ to, label, Icon, match }, i) => {
          const on = (match as readonly string[]).includes(path);
          return (
            <Link key={to} to={to} aria-current={on ? "page" : undefined}
              style={{ animationDelay: `${i * 55}ms` }}
              className={`animate-rise relative flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] transition-colors duration-200 active:scale-90 ${on ? "font-medium text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              {on && <span className="animate-rise absolute inset-x-4 top-0 h-[3px] rounded-b-full bg-primary shadow-[0_0_12px_var(--glow-1)]" />}
              <Icon className={`h-[22px] w-[22px] transition-transform duration-300 ${on ? "-translate-y-0.5 scale-110" : ""}`} />
              {label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
