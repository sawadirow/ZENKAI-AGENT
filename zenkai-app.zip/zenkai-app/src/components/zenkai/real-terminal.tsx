import { useEffect, useRef, useState } from "react";
import { useZ } from "@/lib/zenkai";
import type { TerminalConfig } from "@/lib/terminal-config";

type Status = "connecting" | "live" | "closed";

// A real bash in a Docker container on your terminal server, drawn with xterm.js.
// Project files are copied in when you connect; "Sync back" pulls changed files into the project.
export function RealTerminal({ cfg }: { cfg: TerminalConfig }) {
  const { files, setFile } = useZ();
  const host = useRef<HTMLDivElement>(null);
  const ws = useRef<WebSocket | null>(null);
  const filesRef = useRef(files);
  filesRef.current = files;
  const [status, setStatus] = useState<Status>("connecting");
  const [note, setNote] = useState("");
  const [run, setRun] = useState(0); // bump to reconnect

  useEffect(() => {
    let dead = false;
    let cleanup = () => {};
    setStatus("connecting");
    setNote("");
    (async () => {
      // Loaded here (not at the top) because xterm needs `window` and this page is server-rendered.
      const [{ Terminal }, { FitAddon }] = await Promise.all([
        import("@xterm/xterm"), import("@xterm/addon-fit"), import("@xterm/xterm/css/xterm.css"),
      ]);
      if (dead || !host.current) return;
      const term = new Terminal({ cursorBlink: true, fontSize: 13, scrollback: 5000, convertEol: false,
        theme: { background: "#0b0d10" } });
      const fit = new FitAddon();
      term.loadAddon(fit);
      term.open(host.current);
      fit.fit();

      const u = new URL(cfg.url);
      u.searchParams.set("token", cfg.token);
      u.searchParams.set("cols", String(term.cols));
      u.searchParams.set("rows", String(term.rows));
      const sock = new WebSocket(u);
      ws.current = sock;
      const send = (o: object) => sock.readyState === WebSocket.OPEN && sock.send(JSON.stringify(o));

      sock.onopen = () => { setStatus("live"); send({ t: "files", files: filesRef.current }); term.focus(); };
      sock.onmessage = (e) => {
        let m: { t: string; d?: string; files?: Record<string, string> };
        try { m = JSON.parse(String(e.data)); } catch { return; }
        if (m.t === "o" && m.d) term.write(m.d);
        else if (m.t === "files" && m.files) {
          const cur = filesRef.current;
          const changed = Object.entries(m.files).filter(([k, v]) => cur[k] !== v);
          changed.forEach(([k, v]) => setFile(k, v));
          setNote(changed.length ? `Synced ${changed.length} file(s) into the project` : "Nothing changed");
        } else if (m.t === "exit") term.write("\r\n[session ended]\r\n");
      };
      sock.onclose = (e) => {
        setStatus("closed");
        setNote(e.code === 4001 ? "Wrong token" : e.code === 4003 ? "This site isn't in ALLOWED_ORIGINS" : e.code === 4029 ? "Server busy — try again soon" : e.code === 1006 ? "Can't reach the server (check URL, HTTPS/wss, firewall)" : "");
      };
      const d = term.onData((x) => send({ t: "i", d: x }));
      const ro = new ResizeObserver(() => { fit.fit(); send({ t: "r", c: term.cols, r: term.rows }); });
      ro.observe(host.current);
      cleanup = () => { d.dispose(); ro.disconnect(); sock.close(); term.dispose(); };
    })();
    return () => { dead = true; cleanup(); ws.current = null; };
  }, [cfg.url, cfg.token, run, setFile]);

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-[#0b0d10]">
      <div ref={host} dir="ltr" className="min-h-0 flex-1 p-2" />
      <div className="flex items-center gap-2 border-t border-white/10 px-3 py-2 text-xs text-white/70">
        <span className={`h-2 w-2 rounded-full ${status === "live" ? "bg-green-500" : status === "connecting" ? "animate-pulse bg-yellow-500" : "bg-red-500"}`} />
        <span>{status === "live" ? "Connected" : status === "connecting" ? "Connecting…" : "Disconnected"}</span>
        {note && <span className="truncate text-white/50">· {note}</span>}
        <span className="ml-auto flex gap-1.5">
          {status === "live" && <button onClick={() => ws.current?.send(JSON.stringify({ t: "files", files: filesRef.current }))} className="rounded-lg border border-white/20 px-2 py-1 active:scale-95">Send files</button>}
          {status === "live" && <button onClick={() => ws.current?.send(JSON.stringify({ t: "pull" }))} className="rounded-lg border border-white/20 px-2 py-1 active:scale-95">Sync back</button>}
          {status === "closed" && <button onClick={() => setRun((n) => n + 1)} className="rounded-lg border border-white/20 px-2 py-1 active:scale-95">Reconnect</button>}
        </span>
      </div>
    </div>
  );
}
