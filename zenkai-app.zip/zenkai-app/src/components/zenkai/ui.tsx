import React, { useState } from "react";
import { Check, ChevronRight, FileText, Lightbulb, Pencil, Search, Terminal, X } from "lucide-react";
import type { Msg, Step } from "@/lib/zenkai";

export const StepIcon = ({ t }: { t: Step["icon"] }) =>
  t === "read" ? <FileText className="h-3.5 w-3.5" /> : t === "edit" ? <Pencil className="h-3.5 w-3.5" /> : t === "run" ? <Terminal className="h-3.5 w-3.5" /> : <Search className="h-3.5 w-3.5" />;

export function CodeCard({ lang, code, title }: { lang: string; code: string; title?: string | undefined }) {
  const [copied, setCopied] = useState(false);
  const term = /^(bash|sh|shell|zsh|console|terminal|cmd|powershell)$/i.test(lang);
  const copy = () => { void navigator.clipboard?.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  return (
    <div dir="ltr" className="animate-fade-up overflow-hidden rounded-xl border bg-background text-left">
      <div className="flex items-center gap-2 border-b px-3 py-1.5 text-xs text-muted-foreground">
        {term ? <Terminal className="h-3.5 w-3.5 text-primary" /> : <FileText className="h-3.5 w-3.5 text-primary" />}
        <span>{title ?? (term ? "Shell · ran automatically" : lang || "code")}</span>
        <button onClick={copy} className="ml-auto rounded px-2 py-0.5 hover:bg-accent hover:text-foreground">{copied ? "Copied ✓" : "Copy"}</button>
      </div>
      <pre className="max-h-80 overflow-auto p-3 text-xs leading-relaxed"><code>
        {term ? code.split("\n").map((l, i) => <div key={i}><span className="text-primary">$ </span>{l}</div>) : code}
      </code></pre>
    </div>
  );
}

export function Md({ text }: { text: string }) {
  const lines = text.split("\n"); const out: React.ReactNode[] = []; let code: string[] | null = null; let lang = "";
  const inline = (t: string) => t.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((p, i) =>
    p.startsWith("**") ? <strong key={i}>{p.slice(2, -2)}</strong> : p.startsWith("`") ? <code key={i} dir="ltr" className="rounded bg-secondary px-1 text-[0.85em]">{p.slice(1, -1)}</code> : p);
  lines.forEach((l, i) => {
    if (l.trim().startsWith("```")) { if (code) { if (lang !== "theme") out.push(<FileChip key={i} lang={lang} />); code = null; } else { code = []; lang = (l.trim().slice(3).trim().split(/\s/)[0] ?? "").toLowerCase(); } return; }
    if (code) { code.push(l); return; }
    const h = l.match(/^(#{1,4})\s+(.*)/);
    if (h) out.push(<p key={i} dir="auto" className="mt-2 font-semibold">{inline((h[2] ?? "").replace(/\*\*/g, ""))}</p>);
    else if (/^\s*[-*]\s+/.test(l)) out.push(<p key={i} dir="auto" className="flex gap-2 pl-1"><span className="text-primary">•</span><span>{inline(l.replace(/^\s*[-*]\s+/, ""))}</span></p>);
    else if (l.trim() && l.trim() !== "---") out.push(<p key={i} dir="auto">{inline(l)}</p>);
  });
  if (code && lang !== "theme") out.push(<FileChip key="c" lang={lang} writing />);
  return <div className="space-y-2 text-[15px] leading-relaxed">{out}</div>;
}

export function Timeline({ m }: { m: Msg }) {
  const [open, setOpen] = useState(false);
  const [more, setMore] = useState(false);
  const steps = m.steps ?? [];
  const active = steps.find((s) => !s.done);
  if (m.thinking || active) {
    return (
      <div className="flex items-center gap-2 text-sm">
        <span className="shimmer-text font-medium">{active ? `${active.agent}: ${active.label}` : "Thinking"}</span>
        <span className="flex gap-0.5">{[0, 1, 2].map((i) => <span key={i} className="animate-pulse-dot h-1 w-1 rounded-full bg-primary" style={{ animationDelay: `${i * 150}ms` }} />)}</span>
      </div>
    );
  }
  if (!m.thoughtSecs && !steps.length) return null;
  return (
    <div className="text-sm">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground">
        <span>{`Thought for ${m.thoughtSecs ?? 1}s`}{steps.length ? ` · ${steps.length} steps` : ""}{steps.some((x) => x.file && x.file !== "terminal") ? ` · ${steps.filter((x) => x.file && x.file !== "terminal").length} files` : ""}</span>
        <ChevronRight className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-90" : ""}`} />
      </button>
      {open && (
        <div className="animate-fade-up relative mt-3 space-y-3 pl-7">
          <div className="absolute bottom-2 left-[9px] top-2 w-px bg-border" />
          {m.thoughts && (
            <div className="relative">
              <Lightbulb className="absolute -left-7 top-0.5 h-[18px] w-[18px] bg-background text-primary" />
              <p className={`text-muted-foreground ${more ? "" : "line-clamp-3"}`}>{m.thoughts}</p>
              <button onClick={() => setMore(!more)} className="mt-1 text-xs text-foreground/80 hover:text-foreground">{more ? "Show less" : "Show more"}</button>
            </div>
          )}
          {steps.map((s, i) => <StepRow key={i} s={s} i={i} />)}
        </div>
      )}
    </div>
  );
}

function StepRow({ s, i }: { s: Step; i: number }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="animate-slide-in relative" style={{ animationDelay: `${i * 60}ms` }}>
      <button disabled={!s.code} onClick={() => setOpen(!open)} className="flex w-full items-center gap-2 text-left text-muted-foreground transition enabled:hover:text-foreground">
        <span className="absolute -left-7 flex h-[18px] w-[18px] items-center justify-center bg-background"><StepIcon t={s.icon} /></span>
        <span className="text-foreground/90">{s.agent}</span>
        <span dir="ltr" className={`truncate ${s.file ? "rounded bg-secondary px-1.5 font-mono text-xs" : ""}`}>{s.label}</span>
        {s.code && <ChevronRight className={`h-3.5 w-3.5 shrink-0 transition-transform ${open ? "rotate-90" : ""}`} />}
        {s.fail ? <X className="ml-auto h-3.5 w-3.5 shrink-0 text-destructive" /> : <Check className="ml-auto h-3.5 w-3.5 shrink-0 text-primary" />}
      </button>
      {open && s.code && <div className="mt-2"><CodeCard lang={s.file === "terminal" ? "bash" : s.file?.split(".").pop() ?? ""} code={s.code} title={s.file} /></div>}
    </div>
  );
}

function FileChip({ lang, writing }: { lang: string; writing?: boolean }) {
  const term = /^(bash|sh|shell|zsh|console|terminal)$/i.test(lang);
  return (
    <div dir="ltr" className="animate-pop inline-flex items-center gap-2 rounded-lg border bg-card px-2.5 py-1 text-xs text-muted-foreground">
      {term ? <Terminal className="h-3.5 w-3.5 text-primary" /> : <Pencil className="h-3.5 w-3.5 text-primary" />}
      {writing ? <span className="shimmer-text">Writing {lang || "file"}…</span> : <span>{term ? "Commands ran · see Thinking" : `${lang || "file"} saved · see Thinking`}</span>}
    </div>
  );
}
