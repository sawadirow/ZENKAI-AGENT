import { Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowUp, Check, FileUp, ImagePlus, KeyRound, Monitor, Palette, Plus, Square, SquareTerminal, Sparkles, Trash2, X } from "lucide-react";
import { useZ } from "@/lib/zenkai";
import { Md, Timeline } from "@/components/zenkai/ui";

const SUGGESTIONS = ["Build a todo app", "Make a calculator", "Change the theme to green", "Create a landing page"];

export function ChatPanel() {
  const { msgs, busy, send, stop, decideTheme, clearChat, setFile, actions, saveSecret, skipSecret } = useZ();
  const [input, setInput] = useState("");
  const [plus, setPlus] = useState(false);
  const [imgs, setImgs] = useState<string[]>([]);
  const imgRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [msgs]);
  const go = (t = input) => { if ((!t.trim() && !imgs.length) || busy) return; send(t, imgs); setInput(""); setImgs([]); setPlus(false); };
  const shrink = (f: File) => new Promise<string>((ok) => {
    const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => {
      const k = Math.min(1, 1280 / Math.max(im.width, im.height)); const c = document.createElement("canvas");
      c.width = im.width * k; c.height = im.height * k; c.getContext("2d")!.drawImage(im, 0, 0, c.width, c.height);
      ok(c.toDataURL("image/jpeg", 0.85)); }; im.src = r.result as string; }; r.readAsDataURL(f); });
  const addImgs = async (list: FileList | null) => {
    const out = await Promise.all(Array.from(list ?? []).filter((f) => f.type.startsWith("image/")).map(shrink));
    setImgs((p) => [...p, ...out].slice(0, 6)); setPlus(false);
  };

  const upload = async (list: FileList | null) => {
    const all = Array.from(list ?? []); const pics = all.filter((f) => f.type.startsWith("image/"));
    if (pics.length) { const dt = new DataTransfer(); pics.forEach((f) => dt.items.add(f)); await addImgs(dt.files); }
    for (const f of all.filter((f) => !f.type.startsWith("image/"))) setFile(f.name, await f.text());
    setPlus(false);
  };

  return (
    <>
      <div className="flex-1 space-y-6 overflow-y-auto px-4 py-6">
        {msgs.length === 0 && (
          <div className="animate-fade-up mt-10 text-center">
            <div className="animate-float bg-brand mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl shadow-lg">
              <Sparkles className="h-7 w-7 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-semibold tracking-tight">What do you want to <span className="text-brand">build?</span></h1>
            <p className="mt-3 text-sm text-muted-foreground">The agents write the code, run it, test it and fix errors on their own.</p>
          </div>
        )}
        {msgs.filter((m) => !m.hidden).map((m) =>
          m.role === "user" ? (
            <div key={m.id} className="animate-fade-up flex justify-end">
              <div className="flex max-w-[85%] flex-col items-end gap-2">
                {m.images?.length ? <div className="flex flex-wrap justify-end gap-2">{m.images.map((src, i) => <img key={i} src={src} alt="" className="animate-pop h-28 w-28 rounded-xl border object-cover" />)}</div> : null}
                {m.text && <div dir="auto" className="whitespace-pre-wrap rounded-2xl bg-secondary px-4 py-2.5 text-sm">{m.text}</div>}
              </div>
            </div>
          ) : (
            <div key={m.id} className="animate-fade-up space-y-3">
              <Timeline m={m} />
              {m.text && <Md text={m.text} />}
              {m.secretReqs?.map((r) => <SecretBar key={r.name} r={r} onSave={(v) => saveSecret(m.id, r.name, v)} onSkip={() => skipSecret(m.id, r.name)} />)}
              {m.theme && (
                <div className="animate-pop rounded-2xl border bg-card p-3">
                  <div className="mb-2 flex items-center gap-2 text-sm font-medium"><Palette className="h-4 w-4 text-primary" />Interface redesign</div>
                  <div className="mb-3 flex gap-1.5">{Object.entries(m.theme).filter(([k, v]) => k !== "css" && typeof v === "string").slice(0, 8).map(([k, c]) => <span key={k} className="h-6 w-6 rounded-full border" style={{ background: c as string }} />)}</div>
                  {typeof m.theme["css"] === "string" && (
                    <details className="mb-2 text-xs text-muted-foreground">
                      <summary className="cursor-pointer">+ fonts, shapes, animations &amp; layout ({(m.theme["css"] as string).split("}").length - 1} rules)</summary>
                      <pre dir="ltr" className="mt-2 max-h-48 overflow-auto rounded-lg bg-background p-2 text-[11px]">{m.theme["css"] as string}</pre>
                    </details>
                  )}
                  {Array.isArray(m.theme["actions"]) && <p className="mb-2 text-xs text-muted-foreground">+ {m.theme["actions"].length} new quick button(s)</p>}
                  {m.themeState === "pending" ? (
                    <div className="flex gap-2">
                      <button onClick={() => decideTheme(m.id, true)} className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-primary py-2 text-sm text-primary-foreground transition active:scale-95"><Check className="h-4 w-4" />Approve</button>
                      <button onClick={() => decideTheme(m.id, false)} className="flex flex-1 items-center justify-center gap-1 rounded-xl border py-2 text-sm transition hover:bg-accent active:scale-95"><X className="h-4 w-4" />Reject</button>
                    </div>
                  ) : <p className="text-xs text-muted-foreground">{m.themeState === "applied" ? "Applied ✓ (reset anytime in Settings)" : "Rejected"}</p>}
                </div>
              )}
            </div>
          ),
        )}
        <div ref={endRef} />
      </div>

      <div className="px-3 pb-3">
        {(msgs.length === 0 || actions.length > 0) && (
          <div className="mb-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
            {(actions.length ? actions : SUGGESTIONS.map((t) => ({ label: t, prompt: t }))).map(({ label: t, prompt }) => (
              <button key={t} onClick={() => go(prompt)} className="shrink-0 rounded-full border bg-card px-3.5 py-2 text-sm transition hover:bg-accent active:scale-95">{t}</button>
            ))}
          </div>
        )}
        <div className={`${busy ? "glow-ring" : ""} rounded-[28px] border bg-card px-3 pb-2.5 pt-3 shadow-2xl transition-shadow focus-within:border-muted-foreground/40`}>
          {plus && (
            <div className="animate-fade-up mb-2 space-y-1 rounded-2xl border bg-background p-1.5">
              <button onClick={() => imgRef.current?.click()} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-accent active:scale-[.98]"><ImagePlus className="h-4 w-4 text-muted-foreground" />Attach image</button>
              <input ref={imgRef} type="file" accept="image/*" multiple hidden onChange={(e) => { void addImgs(e.target.files); e.target.value = ""; }} />
              <button onClick={() => fileRef.current?.click()} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-accent active:scale-[.98]"><FileUp className="h-4 w-4 text-muted-foreground" />Upload file to project</button>
              <Link to="/shell" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-accent"><SquareTerminal className="h-4 w-4 text-muted-foreground" />Open shell</Link>
              <Link to="/preview" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-accent"><Monitor className="h-4 w-4 text-muted-foreground" />Open preview</Link>
              <button onClick={() => { clearChat(); setPlus(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-accent"><Trash2 className="h-4 w-4 text-muted-foreground" />New chat</button>
              <input ref={fileRef} type="file" multiple hidden onChange={(e) => void upload(e.target.files)} />
            </div>
          )}
          {imgs.length > 0 && (
            <div className="mb-2 flex gap-2 overflow-x-auto pt-1">
              {imgs.map((src, i) => (
                <div key={i} className="animate-pop relative shrink-0">
                  <img src={src} alt="" className="h-16 w-16 rounded-xl border object-cover" />
                  <button aria-label="Remove image" onClick={() => setImgs((p) => p.filter((_, j) => j !== i))} className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full border bg-background transition active:scale-90"><X className="h-3 w-3" /></button>
                </div>
              ))}
            </div>
          )}
          <textarea value={input} onChange={(e) => { setInput(e.target.value); e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 180) + "px"; }} rows={1} dir="auto"
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); go(); } }}
            placeholder={msgs.length ? "Ask ZENKAI..." : "Ask ZENKAI to build..."}
            className="max-h-[180px] min-h-[28px] w-full resize-none bg-transparent px-1 text-[16px] leading-7 outline-none placeholder:text-muted-foreground" />
          <div className="mt-2 flex items-center gap-1.5">
            <button aria-label="More" onClick={() => setPlus(!plus)} className="flex h-9 w-9 items-center justify-center rounded-full border transition hover:bg-accent active:scale-90">
              <Plus className={`h-[18px] w-[18px] transition-transform duration-300 ${plus ? "rotate-45" : ""}`} />
            </button>
            <span className="flex h-9 items-center gap-1.5 rounded-full border px-3 text-sm text-muted-foreground"><Sparkles className="h-3.5 w-3.5" />Build</span>
            <div className="ml-auto" />
            {busy ? (
              <button aria-label="Stop" onClick={stop} className="animate-pop flex h-9 w-9 items-center justify-center rounded-full bg-foreground text-background active:scale-90"><Square className="h-3.5 w-3.5 fill-current" /></button>
            ) : (
              <button aria-label="Send" onClick={() => go()} disabled={!input.trim() && !imgs.length} className="flex h-9 w-9 items-center justify-center rounded-full bg-foreground text-background transition active:scale-90 disabled:bg-muted disabled:text-muted-foreground"><ArrowUp className="h-[18px] w-[18px]" /></button>
            )}
          </div>

        </div>
      </div>
    </>
  );
}

// Inline "enter your API key" bar. The value goes to the local vault, never into the chat or to the AI.
function SecretBar({ r, onSave, onSkip }: { r: { name: string; desc: string; state: "pending" | "saved" | "skipped" }; onSave: (v: string) => void; onSkip: () => void }) {
  const [v, setV] = useState("");
  return (
    <div className="animate-rise rounded-2xl border border-primary/40 bg-card p-3">
      <div className="mb-1 flex items-center gap-2 text-sm font-medium"><KeyRound className="h-4 w-4 text-primary" /><span dir="ltr">{r.name}</span></div>
      {r.desc && <p className="mb-2 text-xs text-muted-foreground">{r.desc}</p>}
      {r.state === "pending" ? (
        <div className="flex gap-2">
          <input dir="ltr" type="password" autoComplete="off" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && v.trim()) onSave(v); }}
            placeholder="Paste the key here" className="min-w-0 flex-1 rounded-xl border bg-background px-3 py-2 text-base outline-none focus:border-primary" />
          <button disabled={!v.trim()} onClick={() => onSave(v)} className="rounded-xl bg-primary px-3 text-sm font-medium text-primary-foreground disabled:opacity-40">Save</button>
          <button onClick={onSkip} className="rounded-xl border px-3 text-sm">Skip</button>
        </div>
      ) : <p className="text-xs text-muted-foreground">{r.state === "saved" ? "Saved securely on this device ✓" : "Skipped"}</p>}
    </div>
  );
}
