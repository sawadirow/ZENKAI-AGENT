import { useMemo, useRef, useState, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Check, Copy, Download, ExternalLink, KeyRound, Plus, RotateCcw, Share2, Trash2, Play, Upload } from "lucide-react";
import { useZ } from "@/lib/zenkai";
import { buildPage } from "@/lib/sandbox";
import { KEYS, newId, useStored, validSecretName, type Checkpoint, type Secret, type Skill, type Workflow } from "@/lib/store";

/* ───────── shared bits ───────── */
const box = "animate-rise rounded-2xl border bg-card p-4";
const field = "w-full rounded-xl border bg-background px-3 py-2 text-base outline-none focus:border-primary";
const primaryBtn = "rounded-xl bg-primary px-3 py-2 text-sm font-medium text-primary-foreground disabled:opacity-40";
const ghostBtn = "rounded-xl border px-3 py-2 text-sm hover:bg-accent";
const Page = ({ children }: { children: ReactNode }) => <div className="flex-1 space-y-3 overflow-y-auto p-4">{children}</div>;
const Note = ({ children }: { children: ReactNode }) => <p className="text-sm leading-relaxed text-muted-foreground">{children}</p>;

function download(name: string, text: string, type = "text/plain") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
const fmtBytes = (n: number) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`);

/* ───────── Secrets ───────── */
export function Secrets() {
  const [list, setList] = useStored<Secret[]>(KEYS.secrets, []);
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  const [desc, setDesc] = useState("");
  const n = name.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "_");
  const add = () => {
    if (!validSecretName(n) || !value.trim()) return;
    setList((p) => [...p.filter((x) => x.name !== n), { name: n, value: value.trim(), desc: desc.trim() || undefined }]);
    setName(""); setValue(""); setDesc("");
  };
  return (
    <Page>
      <Note>Keys are stored on this device only. The AI sees the <b>names</b> (so it knows what's available) and can ask you for a missing one — it never sees the values. Python reads them with <code dir="ltr">os.environ["NAME"]</code>; the shell with <code dir="ltr">printenv NAME</code>.</Note>
      <div className={`${box} space-y-2`}>
        <input dir="ltr" value={name} onChange={(e) => setName(e.target.value)} placeholder="OPENAI_API_KEY" className={field} />
        <input dir="ltr" type="password" autoComplete="off" value={value} onChange={(e) => setValue(e.target.value)} placeholder="Value" className={field} />
        <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="What it's for (optional — the AI reads this)" className={field} />
        <button disabled={!validSecretName(n) || !value.trim()} onClick={add} className={primaryBtn}><Plus className="mr-1 inline h-4 w-4" />Save secret</button>
      </div>
      {list.length === 0 && <Note>No secrets yet.</Note>}
      {list.map((s) => (
        <div key={s.name} className={`${box} flex items-center gap-3`}>
          <KeyRound className="h-4 w-4 shrink-0 text-primary" />
          <div className="min-w-0 flex-1"><p dir="ltr" className="truncate font-mono text-sm">{s.name}</p><p className="truncate text-xs text-muted-foreground">{s.desc || "••••••••"}</p></div>
          <button aria-label={`Delete ${s.name}`} onClick={() => setList((p) => p.filter((x) => x.name !== s.name))} className="rounded-lg p-2 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
        </div>
      ))}
    </Page>
  );
}

/* ───────── Integrations ───────── */
const PRESETS: { label: string; hint: string; names: string[] }[] = [
  { label: "OpenAI", hint: "GPT / image / speech APIs", names: ["OPENAI_API_KEY"] },
  { label: "Anthropic", hint: "Claude API", names: ["ANTHROPIC_API_KEY"] },
  { label: "Google Gemini", hint: "Gemini API", names: ["GEMINI_API_KEY"] },
  { label: "Stripe", hint: "Payments", names: ["STRIPE_SECRET_KEY"] },
  { label: "Supabase", hint: "Database + auth", names: ["SUPABASE_URL", "SUPABASE_ANON_KEY"] },
  { label: "GitHub", hint: "Repos and issues", names: ["GITHUB_TOKEN"] },
  { label: "Telegram Bot", hint: "Bot token from @BotFather", names: ["TELEGRAM_BOT_TOKEN"] },
  { label: "Resend", hint: "Email sending", names: ["RESEND_API_KEY"] },
];
export function Integrations() {
  const [list, setList] = useStored<Secret[]>(KEYS.secrets, []);
  const [open, setOpen] = useState<string | null>(null);
  const [vals, setVals] = useState<Record<string, string>>({});
  const have = new Set(list.map((s) => s.name));
  const save = (p: (typeof PRESETS)[number]) => {
    const add = p.names.filter((n) => vals[n]?.trim()).map((n) => ({ name: n, value: vals[n]!.trim(), desc: `${p.label} — ${p.hint}` }));
    setList((cur) => [...cur.filter((s) => !add.some((a) => a.name === s.name)), ...add]);
    setVals({}); setOpen(null);
  };
  return (
    <Page>
      <Note>Connect a service by saving its keys. They land in <b>Secrets</b>, and the AI can then use them by name.</Note>
      {PRESETS.map((p, i) => {
        const done = p.names.every((n) => have.has(n));
        return (
          <div key={p.label} className={box} style={{ animationDelay: `${i * 40}ms` }}>
            <div className="flex items-center gap-3">
              <div className="flex-1"><p className="font-medium">{p.label}</p><p className="text-xs text-muted-foreground">{p.hint}</p></div>
              {done ? <span className="flex items-center gap-1 text-xs text-primary"><Check className="h-4 w-4" />Connected</span>
                : <button onClick={() => setOpen(open === p.label ? null : p.label)} className={ghostBtn}>Connect</button>}
            </div>
            {open === p.label && (
              <div className="mt-3 space-y-2">
                {p.names.map((n) => <input key={n} dir="ltr" type="password" autoComplete="off" placeholder={n} value={vals[n] ?? ""} onChange={(e) => setVals((v) => ({ ...v, [n]: e.target.value }))} className={field} />)}
                <button disabled={!p.names.some((n) => vals[n]?.trim())} onClick={() => save(p)} className={primaryBtn}>Save</button>
              </div>
            )}
          </div>
        );
      })}
    </Page>
  );
}

/* ───────── Git → local checkpoints ───────── */
export function Git() {
  const { files, setFile, delFile } = useZ();
  const [list, setList] = useStored<Checkpoint[]>(KEYS.checkpoints, []);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const commit = () => {
    const ok = setList((p) => [{ id: newId(), msg: msg.trim() || "Checkpoint", at: Date.now(), files }, ...p].slice(0, 30));
    setErr(ok ? "" : "Browser storage is full — delete old checkpoints."); if (ok) setMsg("");
  };
  const diff = (c: Checkpoint) => {
    const a = Object.keys(files), b = Object.keys(c.files);
    return { added: a.filter((k) => !(k in c.files)).length, removed: b.filter((k) => !(k in files)).length, changed: a.filter((k) => k in c.files && c.files[k] !== files[k]).length };
  };
  const restore = (c: Checkpoint) => {
    if (!confirm("Replace current files with this checkpoint?")) return;
    Object.keys(files).forEach((k) => { if (!(k in c.files)) delFile(k); });
    Object.entries(c.files).forEach(([k, v]) => setFile(k, v));
  };
  return (
    <Page>
      <Note>Local version history in this browser — save a snapshot before risky changes and restore it any time. It isn't real git; for real <code dir="ltr">git</code> (clone, push) use the <b>Real Linux</b> shell.</Note>
      <div className={`${box} space-y-2`}>
        <input value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="What changed? (optional)" className={field} />
        <button onClick={commit} disabled={!Object.keys(files).length} className={primaryBtn}>Save checkpoint</button>
        {err && <p className="text-xs text-destructive">{err}</p>}
      </div>
      {list.map((c) => { const d = diff(c); return (
        <div key={c.id} className={box}>
          <p className="font-medium">{c.msg}</p>
          <p className="text-xs text-muted-foreground">{new Date(c.at).toLocaleString()} · {Object.keys(c.files).length} files · now: +{d.added} ~{d.changed} −{d.removed}</p>
          <div className="mt-2 flex gap-2">
            <button onClick={() => restore(c)} className={ghostBtn}><RotateCcw className="mr-1 inline h-4 w-4" />Restore</button>
            <button onClick={() => setList((p) => p.filter((x) => x.id !== c.id))} className={`${ghostBtn} text-destructive`}><Trash2 className="inline h-4 w-4" /></button>
          </div>
        </div>); })}
    </Page>
  );
}

/* ───────── Agent Skills ───────── */
const SKILL_IDEAS = ["Always write mobile-first, responsive UI", "Explain every change in one short sentence", "Prefer plain JavaScript, no frameworks"];
export function AgentSkills() {
  const [list, setList] = useStored<Skill[]>(KEYS.skills, []);
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const add = (t: string, x: string) => setList((p) => [...p, { id: newId(), title: t, text: x, on: true }].slice(0, 10));
  return (
    <Page>
      <Note>Standing instructions the AI follows in every request (up to 10 active). Turn them on and off without deleting.</Note>
      <div className={`${box} space-y-2`}>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Skill name" className={field} />
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3} placeholder="Instructions…" className={field} />
        <button disabled={!title.trim() || !text.trim()} onClick={() => { add(title.trim(), text.trim()); setTitle(""); setText(""); }} className={primaryBtn}>Add skill</button>
        <div className="flex flex-wrap gap-1.5 pt-1">{SKILL_IDEAS.map((t) => <button key={t} onClick={() => add(t, t)} className="rounded-full border px-2.5 py-1 text-xs hover:bg-accent">+ {t}</button>)}</div>
      </div>
      {list.map((k) => (
        <div key={k.id} className={`${box} flex items-start gap-3`}>
          <button aria-label="Toggle" onClick={() => setList((p) => p.map((x) => (x.id === k.id ? { ...x, on: !x.on } : x)))} className={`mt-0.5 h-6 w-11 shrink-0 rounded-full border transition ${k.on ? "bg-primary" : "bg-secondary"}`}><span className={`block h-4 w-4 rounded-full bg-white transition-transform ${k.on ? "translate-x-6" : "translate-x-1"}`} /></button>
          <div className="min-w-0 flex-1"><p className="font-medium">{k.title}</p><p className="line-clamp-3 text-xs text-muted-foreground">{k.text}</p></div>
          <button aria-label="Delete" onClick={() => setList((p) => p.filter((x) => x.id !== k.id))} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
        </div>
      ))}
    </Page>
  );
}

/* ───────── Console ───────── */
export function Console() {
  const { lines, exec } = useZ();
  return (
    <div dir="ltr" className="flex min-h-0 flex-1 flex-col font-mono text-xs">
      <div className="flex items-center gap-2 border-b p-2"><span className="text-muted-foreground">Output of everything that ran (you and the AI)</span><button onClick={() => void exec("clear")} className="ml-auto rounded-lg border px-2 py-1">Clear</button></div>
      <div className="flex-1 overflow-y-auto p-3 leading-relaxed">
        {lines.length === 0 && <p className="text-muted-foreground">Nothing has run yet.</p>}
        {lines.map((l, i) => <div key={i} className={`whitespace-pre-wrap ${l.t === "err" ? "text-destructive" : l.t === "in" ? "text-foreground" : "text-muted-foreground"}`}>{l.t === "in" ? "$ " : ""}{l.s}</div>)}
      </div>
    </div>
  );
}

/* ───────── Workflows ───────── */
export function Workflows() {
  const { exec } = useZ();
  const [list, setList] = useStored<Workflow[]>(KEYS.workflows, []);
  const [name, setName] = useState("");
  const [cmds, setCmds] = useState("");
  const [running, setRunning] = useState<string | null>(null);
  const run = async (w: Workflow) => { setRunning(w.id); try { for (const c of w.cmds) await exec(c); } finally { setRunning(null); } };
  return (
    <Page>
      <Note>Save a list of shell commands and run them with one tap. Output appears in <b>Console</b> and Shell.</Note>
      <div className={`${box} space-y-2`}>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Workflow name (e.g. Test)" className={field} />
        <textarea dir="ltr" value={cmds} onChange={(e) => setCmds(e.target.value)} rows={3} placeholder={"One command per line\ntest\npython main.py"} className={`${field} font-mono text-sm`} />
        <button disabled={!name.trim() || !cmds.trim()} onClick={() => { setList((p) => [...p, { id: newId(), name: name.trim(), cmds: cmds.split("\n").map((c) => c.trim()).filter(Boolean) }]); setName(""); setCmds(""); }} className={primaryBtn}>Save workflow</button>
      </div>
      {list.map((w) => (
        <div key={w.id} className={box}>
          <div className="flex items-center gap-2"><p className="flex-1 font-medium">{w.name}</p>
            <button disabled={running !== null} onClick={() => void run(w)} className={primaryBtn}><Play className="mr-1 inline h-4 w-4" />{running === w.id ? "Running…" : "Run"}</button>
            <button aria-label="Delete" onClick={() => setList((p) => p.filter((x) => x.id !== w.id))} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button></div>
          <pre dir="ltr" className="mt-2 overflow-x-auto rounded-lg bg-background p-2 text-xs">{w.cmds.map((c) => `$ ${c}`).join("\n")}</pre>
        </div>
      ))}
    </Page>
  );
}

/* ───────── Publishing ───────── */
export function Publishing() {
  const { files } = useZ();
  const html = useMemo(() => buildPage(files), [files]);
  const [copied, setCopied] = useState(false);
  const title = /<title>([^<]+)<\/title>/i.exec(html)?.[1];
  const checks = [
    { ok: !!files["index.html"], t: "Has an index.html" },
    { ok: !!title, t: "Has a page title" },
    { ok: html.length > 0 && html.length < 2_000_000, t: "Size is reasonable" },
  ];
  const openTab = () => { const u = URL.createObjectURL(new Blob([html], { type: "text/html" })); window.open(u, "_blank", "noopener"); setTimeout(() => URL.revokeObjectURL(u), 60_000); };
  const share = () => { void navigator.share?.({ title: title ?? "ZENKAI app", text: "Built with ZENKAI", files: [new File([html], "index.html", { type: "text/html" })] }).catch(() => {}); };
  if (!html) return <Page><Note>Nothing to publish yet — ask ZENKAI to build a web app first.</Note></Page>;
  return (
    <Page>
      <div className={box}>
        <p className="font-medium">Your app, as one file</p>
        <p className="text-xs text-muted-foreground">{fmtBytes(new Blob([html]).size)} · HTML + CSS + JS inlined</p>
        <ul className="mt-2 space-y-1 text-sm">{checks.map((c) => <li key={c.t} className="flex items-center gap-2"><Check className={`h-4 w-4 ${c.ok ? "text-primary" : "text-muted-foreground opacity-40"}`} />{c.t}</li>)}</ul>
        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={() => download("index.html", html, "text/html")} className={primaryBtn}><Download className="mr-1 inline h-4 w-4" />Download</button>
          <button onClick={openTab} className={ghostBtn}><ExternalLink className="mr-1 inline h-4 w-4" />Open</button>
          <button onClick={() => { void navigator.clipboard?.writeText(html); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className={ghostBtn}><Copy className="mr-1 inline h-4 w-4" />{copied ? "Copied" : "Copy"}</button>
          {typeof navigator !== "undefined" && "share" in navigator && <button onClick={share} className={ghostBtn}><Share2 className="mr-1 inline h-4 w-4" />Share</button>}
        </div>
      </div>
      <Note>This exports a ready-to-host file. A public link needs a host: drop <code dir="ltr">index.html</code> on Cloudflare Pages, Netlify or GitHub Pages. One-click hosting from inside ZENKAI isn't built yet.</Note>
    </Page>
  );
}

/* ───────── Growth (SEO audit) ───────── */
export function Growth() {
  const { files } = useZ();
  const html = useMemo(() => buildPage(files), [files]);
  if (!html) return <Page><Note>Build a web app first — then this audits its SEO basics.</Note></Page>;
  const d = new DOMParser().parseFromString(html, "text/html");
  const meta = (n: string) => d.querySelector(`meta[name="${n}"]`)?.getAttribute("content") ?? "";
  const og = (n: string) => d.querySelector(`meta[property="${n}"]`)?.getAttribute("content") ?? "";
  const imgs = [...d.querySelectorAll("img")];
  const blank = [...d.querySelectorAll('a[target="_blank"]')].filter((a) => !/noopener/.test(a.getAttribute("rel") ?? ""));
  const t = d.title.trim();
  const items: [boolean, string, string][] = [
    [t.length >= 10 && t.length <= 60, "Title 10–60 characters", t ? `Now ${t.length}` : "Missing <title>"],
    [meta("description").length >= 50 && meta("description").length <= 160, "Meta description 50–160 characters", meta("description") ? `Now ${meta("description").length}` : "Missing"],
    [!!meta("viewport"), "Mobile viewport tag", "Add <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"],
    [!!d.documentElement.getAttribute("lang"), "<html lang> set", "Add lang=\"ar\" or \"en\""],
    [d.querySelectorAll("h1").length === 1, "Exactly one <h1>", `Found ${d.querySelectorAll("h1").length}`],
    [imgs.every((i) => i.hasAttribute("alt")), "Every image has alt text", `${imgs.filter((i) => !i.hasAttribute("alt")).length} missing`],
    [!!og("og:title") && !!og("og:description"), "Open Graph title + description", "Used for link previews"],
    [!!d.querySelector('link[rel~="icon"]'), "Favicon", "Add <link rel=\"icon\">"],
    [blank.length === 0, "External links use rel=noopener", `${blank.length} links need it`],
  ];
  const score = Math.round((items.filter((i) => i[0]).length / items.length) * 100);
  return (
    <Page>
      <div className={box}><p className="text-3xl font-semibold">{score}<span className="text-base text-muted-foreground">/100</span></p><p className="text-xs text-muted-foreground">SEO basics of your current page</p></div>
      {items.map(([ok, label, hint]) => <div key={label} className={`${box} flex items-start gap-3`}><Check className={`mt-0.5 h-4 w-4 shrink-0 ${ok ? "text-primary" : "text-destructive"}`} /><div><p className="text-sm">{label}</p>{!ok && <p className="text-xs text-muted-foreground">{hint}</p>}</div></div>)}
    </Page>
  );
}

/* ───────── Security Center ───────── */
const PATTERNS: { re: RegExp; label: string; sev: "high" | "med" }[] = [
  { re: /\bsk-[A-Za-z0-9_-]{20,}/, label: "Looks like an OpenAI/Anthropic-style API key", sev: "high" },
  { re: /\bAIza[0-9A-Za-z_-]{35}\b/, label: "Looks like a Google API key", sev: "high" },
  { re: /\bgh[pousr]_[A-Za-z0-9]{30,}\b/, label: "Looks like a GitHub token", sev: "high" },
  { re: /\bxox[baprs]-[A-Za-z0-9-]{10,}/, label: "Looks like a Slack token", sev: "high" },
  { re: /-----BEGIN [A-Z ]*PRIVATE KEY-----/, label: "Private key in the project", sev: "high" },
  { re: /\b(password|passwd|secret|token)\s*[:=]\s*["'][^"']{6,}["']/i, label: "Hard-coded password/secret", sev: "high" },
  { re: /\beval\s*\(/, label: "eval() runs arbitrary strings as code", sev: "med" },
  { re: /\.innerHTML\s*=/, label: "innerHTML can allow XSS with untrusted data", sev: "med" },
  { re: /document\.write\s*\(/, label: "document.write is unsafe and slow", sev: "med" },
  { re: /["']http:\/\/(?!localhost|127\.)/, label: "Plain http:// link (use https)", sev: "med" },
];
export function SecurityCenter() {
  const { files } = useZ();
  const [secrets] = useStored<Secret[]>(KEYS.secrets, []);
  const found: { file: string; line: number; label: string; sev: "high" | "med" }[] = [];
  for (const [file, text] of Object.entries(files)) {
    text.split("\n").forEach((ln, i) => {
      for (const p of PATTERNS) if (p.re.test(ln)) found.push({ file, line: i + 1, label: p.label, sev: p.sev });
      for (const s of secrets) if (s.value.length >= 8 && ln.includes(s.value)) found.push({ file, line: i + 1, label: `Your saved secret ${s.name} is written in this file`, sev: "high" });
    });
  }
  return (
    <Page>
      <div className={box}><p className="font-medium">{found.length === 0 ? "No issues found" : `${found.length} issue(s) found`}</p><p className="text-xs text-muted-foreground">Static scan of {Object.keys(files).length} project files. It catches common mistakes — it is not a full audit.</p></div>
      {found.slice(0, 80).map((f, i) => (
        <div key={i} className={box}><p className={`text-xs font-medium ${f.sev === "high" ? "text-destructive" : "text-primary"}`}>{f.sev === "high" ? "High" : "Medium"}</p><p className="text-sm">{f.label}</p><p dir="ltr" className="font-mono text-xs text-muted-foreground">{f.file}:{f.line}</p></div>
      ))}
    </Page>
  );
}

/* ───────── Monitoring ───────── */
export function Monitoring() {
  const { files, msgs, lines } = useZ();
  const [ping, setPing] = useState<string>("");
  const check = async () => {
    setPing("Checking…");
    const t0 = performance.now();
    try { const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }); setPing(r.status === 400 || r.status === 429 ? `AI endpoint reachable · ${Math.round(performance.now() - t0)} ms` : `Unexpected status ${r.status}`); }
    catch { setPing("Can't reach the server"); }
  };
  const stat = (label: string, v: string | number) => <div className={box}><p className="text-2xl font-semibold">{v}</p><p className="text-xs text-muted-foreground">{label}</p></div>;
  return (
    <Page>
      <div className="grid grid-cols-2 gap-3">
        {stat("Messages", msgs.length)}{stat("Project files", Object.keys(files).length)}{stat("Shell errors", lines.filter((l) => l.t === "err").length)}{stat("Commands run", lines.filter((l) => l.t === "in").length)}
      </div>
      <div className={`${box} space-y-2`}><button onClick={() => void check()} className={primaryBtn}>Run health check</button>{ping && <p className="text-sm text-muted-foreground">{ping}</p>}</div>
      <Note>This shows the health of ZENKAI itself. Live metrics, uptime and alerts for a <i>published</i> app need a hosting platform's analytics (Cloudflare, Netlify, …).</Note>
    </Page>
  );
}

/* ───────── Developer ───────── */
export function Developer() {
  const { files, setFile } = useZ();
  const inp = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState("");
  const used = typeof localStorage === "undefined" ? 0 : Object.keys(localStorage).reduce((n, k) => n + k.length + (localStorage.getItem(k)?.length ?? 0), 0);
  const imp = async (f: File | undefined) => {
    if (!f) return;
    try { const j = JSON.parse(await f.text()) as { files?: Record<string, unknown> }; const e = Object.entries(j.files ?? {}).filter(([, v]) => typeof v === "string") as [string, string][]; e.forEach(([k, v]) => setFile(k, v)); setMsg(`Imported ${e.length} file(s)`); }
    catch { setMsg("Not a valid ZENKAI project file"); }
  };
  const row = (k: string, v: string) => <div className="flex justify-between gap-4 text-sm"><span className="text-muted-foreground">{k}</span><span dir="ltr" className="truncate text-right">{v}</span></div>;
  return (
    <Page>
      <div className={`${box} space-y-1.5`}>
        {row("Files", String(Object.keys(files).length))}
        {row("Project size", fmtBytes(Object.values(files).reduce((n, t) => n + t.length, 0)))}
        {row("Browser storage used", `${fmtBytes(used * 2)} of ~5 MB`)}
        {row("Browser", typeof navigator === "undefined" ? "" : navigator.userAgent.slice(0, 60))}
        {row("Cross-origin isolated", typeof crossOriginIsolated === "undefined" ? "?" : String(crossOriginIsolated))}
      </div>
      <div className={`${box} space-y-2`}>
        <p className="font-medium">Backup</p>
        <div className="flex gap-2">
          <button onClick={() => download("zenkai-project.json", JSON.stringify({ files }, null, 2), "application/json")} className={primaryBtn}><Download className="mr-1 inline h-4 w-4" />Export project</button>
          <button onClick={() => inp.current?.click()} className={ghostBtn}><Upload className="mr-1 inline h-4 w-4" />Import</button>
          <input ref={inp} type="file" accept="application/json" hidden onChange={(e) => { void imp(e.target.files?.[0]); e.target.value = ""; }} />
        </div>
        <p className="text-xs text-muted-foreground">Secrets are never included in exports.</p>{msg && <p className="text-xs text-primary">{msg}</p>}
      </div>
    </Page>
  );
}

/* ───────── Library ───────── */
export function LibraryPanel() {
  const { files } = useZ();
  const kind = (n: string) => (/\.(html?|css|jsx?|tsx?)$/i.test(n) ? "Web" : /\.py$/i.test(n) ? "Python" : /\.(json|csv|txt|md)$/i.test(n) ? "Data & docs" : "Other");
  const groups: Record<string, string[]> = {};
  Object.keys(files).sort().forEach((n) => (groups[kind(n)] ??= []).push(n));
  if (!Object.keys(files).length) return <Page><Note>Your project's files and assets will be listed here.</Note></Page>;
  return (
    <Page>
      {Object.entries(groups).map(([g, names]) => (
        <div key={g} className={box}><p className="mb-2 text-sm font-medium">{g}</p>
          {names.map((n) => <div key={n} className="flex items-center gap-2 py-1 text-sm"><span dir="ltr" className="flex-1 truncate">{n}</span><span className="text-xs text-muted-foreground">{fmtBytes(files[n]!.length)}</span><button aria-label={`Download ${n}`} onClick={() => download(n.split("/").pop() ?? n, files[n]!)} className="text-muted-foreground hover:text-foreground"><Download className="h-4 w-4" /></button></div>)}
        </div>
      ))}
    </Page>
  );
}

/* ───────── Needs a backend ───────── */
function NeedsBackend({ what, why, options, prompt }: { what: string; why: string; options: string[]; prompt: string }) {
  const { send } = useZ();
  const nav = useNavigate();
  return (
    <Page>
      <div className={box}><p className="font-medium">Not connected yet</p><p className="mt-1 text-sm text-muted-foreground">{what}</p></div>
      <div className={box}><p className="text-sm font-medium">Why</p><p className="mt-1 text-sm text-muted-foreground">{why}</p></div>
      <div className={box}><p className="text-sm font-medium">Options</p><ul className="mt-1 list-disc space-y-1 ps-5 text-sm text-muted-foreground">{options.map((o) => <li key={o}>{o}</li>)}</ul></div>
      <button onClick={() => { send(prompt); void nav({ to: "/" }); }} className={`${primaryBtn} w-full`}>Ask ZENKAI to plan it</button>
    </Page>
  );
}
export const Database = () => <NeedsBackend what="Store structured data like profiles, scores and catalogs." why="ZENKAI runs in the browser plus two small API routes. There's no database attached, so nothing here can persist across devices." options={["Supabase (Postgres + auth + storage) — save its keys in Integrations", "Cloudflare D1 if you deploy on Cloudflare", "Firebase Firestore"]} prompt="Help me choose and set up a database for my project. Ask me which one I prefer, request the keys you need as secrets, and write the code." />;
export const UsersAuth = () => <NeedsBackend what="A ready login page so users can sign in to your app." why="Real accounts need a server that stores users and checks passwords. This build has none, so a fake login would only give a false sense of security." options={["Supabase Auth (email, Google, magic link)", "Clerk or Auth0 (hosted login pages)", "Firebase Auth"]} prompt="Add user login to my app. Ask me which auth provider to use, request the keys you need as secrets, and be honest about what runs in the browser versus what needs a server." />;
export const AppStorage = () => <NeedsBackend what="Host and save uploaded images, videos and documents." why="Uploads need a bucket on a server. The browser can't safely keep large files or share them between users." options={["Supabase Storage", "Cloudflare R2", "Firebase Storage / S3"]} prompt="Add file upload and storage to my app. Ask me which storage provider to use, request the keys you need as secrets, and write the upload code." />;
