import type { ComponentType } from "react";
import { Activity, Database as DbIcon, FolderTree, GitBranch, HardDrive, KeyRound, Library, Plug, Rocket, Settings, ShieldCheck, Sparkles, SquareTerminal, Terminal, TrendingUp, Users, Workflow, Wrench } from "lucide-react";
import * as P from "./panels";

export type Status = "live" | "local" | "backend";
type Base = { title: string; desc: string; Icon: ComponentType<{ className?: string }>; status: Status };
export type Tool = (Base & { id: string; Panel: ComponentType }) | (Base & { id: string; to: "/shell" | "/files" | "/settings" });
export type Group = { name: string; tools: Tool[] };

export const GROUPS: Group[] = [
  { name: "Publish", tools: [
    { id: "publishing", title: "Publishing", desc: "Export a shareable version of your app", Icon: Rocket, status: "local", Panel: P.Publishing },
    { id: "monitoring", title: "Monitoring", desc: "App health, request metrics and alerts", Icon: Activity, status: "local", Panel: P.Monitoring },
    { id: "growth", title: "Growth", desc: "Find and fix SEO and growth opportunities", Icon: TrendingUp, status: "live", Panel: P.Growth },
  ] },
  { name: "Data & security", tools: [
    { id: "database", title: "Database", desc: "Structured data: profiles, scores, catalogs", Icon: DbIcon, status: "backend", Panel: P.Database },
    { id: "auth", title: "Users & Auth", desc: "Let users log in with a prebuilt login page", Icon: Users, status: "backend", Panel: P.UsersAuth },
    { id: "security", title: "Security Center", desc: "Find leaked keys and risky code", Icon: ShieldCheck, status: "live", Panel: P.SecurityCenter },
    { id: "storage", title: "App Storage", desc: "Host uploads: images, videos, documents", Icon: HardDrive, status: "backend", Panel: P.AppStorage },
  ] },
  { name: "Setup", tools: [
    { id: "integrations", title: "Integrations", desc: "Connect external services", Icon: Plug, status: "live", Panel: P.Integrations },
    { id: "git", title: "Git", desc: "Version history for your app", Icon: GitBranch, status: "local", Panel: P.Git },
    { id: "secrets", title: "Secrets", desc: "Store API keys securely on your device", Icon: KeyRound, status: "live", Panel: P.Secrets },
    { id: "skills", title: "Agent Skills", desc: "Instructions that extend the AI", Icon: Sparkles, status: "live", Panel: P.AgentSkills },
  ] },
  { name: "Run", tools: [
    { id: "console", title: "Console", desc: "Output of everything that ran", Icon: Terminal, status: "live", Panel: P.Console },
    { id: "shell", title: "Shell", desc: "Command line for your app", Icon: SquareTerminal, status: "live", to: "/shell" },
    { id: "workflows", title: "Workflows", desc: "Saved command sequences", Icon: Workflow, status: "live", Panel: P.Workflows },
  ] },
  { name: "Developer", tools: [
    { id: "developer", title: "Developer", desc: "Diagnostics, backup and import", Icon: Wrench, status: "live", Panel: P.Developer },
    { id: "files", title: "Files", desc: "Browse and edit your project files", Icon: FolderTree, status: "live", to: "/files" },
    { id: "library", title: "Library", desc: "Browse and download assets", Icon: Library, status: "live", Panel: P.LibraryPanel },
    { id: "settings", title: "Settings", desc: "Style, chat, project and terminal server", Icon: Settings, status: "live", to: "/settings" },
  ] },
];

export const ALL_TOOLS = GROUPS.flatMap((g) => g.tools);
export const STATUS_LABEL: Record<Status, string> = { live: "", local: "On this device", backend: "Needs backend" };
