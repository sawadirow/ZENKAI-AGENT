import { describe, expect, it } from "vitest";
import { buildPage, withHook } from "@/lib/sandbox";

describe("sandbox", () => {
  it("returns nothing when there is no html or js", () => {
    expect(buildPage({})).toBe("");
  });
  it("inlines css and js and drops external links to them", () => {
    const page = buildPage({
      "index.html": '<html><head><link rel="stylesheet" href="style.css"></head><body><script src="script.js"></script></body></html>',
      "style.css": "body{color:red}",
      "script.js": "console.log(1)",
    });
    expect(page).toContain("<style>body{color:red}</style>");
    expect(page).toContain("console.log(1)");
    expect(page).not.toContain('href="style.css"');
    expect(page).not.toContain('src="script.js"');
  });
  it("embeds the per-run nonce in the console hook", () => {
    expect(withHook("<head></head>", "abc-123")).toContain('"abc-123"');
  });
});
