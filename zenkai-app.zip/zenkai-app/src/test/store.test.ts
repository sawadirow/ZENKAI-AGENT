import { describe, expect, it } from "vitest";
import { validSecretName } from "@/lib/store";

describe("secret names", () => {
  it.each(["OPENAI_API_KEY", "A1", "SUPABASE_URL"])("accepts %s", (n) => expect(validSecretName(n)).toBe(true));
  it.each(["", "a", "lower_case", "1ABC", "HAS SPACE", "X-Y", "A".repeat(80)])("rejects %j", (n) => expect(validSecretName(n)).toBe(false));
});
