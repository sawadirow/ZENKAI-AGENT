import { describe, expect, it } from "vitest";
import { isPrivateHost, parsePublicUrl } from "@/lib/url-guard";

describe("url guard", () => {
  it.each(["localhost", "127.0.0.1", "10.1.2.3", "192.168.1.5", "172.16.0.1", "172.31.255.1", "169.254.169.254",
    "0.0.0.0", "100.64.0.1", "[::1]", "fd00::1", "metadata.google.internal", "printer.local"])("blocks %s", (h) => {
    expect(isPrivateHost(h)).toBe(true);
  });
  it.each(["example.com", "8.8.8.8", "172.32.0.1", "api.github.com"])("allows %s", (h) => {
    expect(isPrivateHost(h)).toBe(false);
  });
  it("normalises tricky IP forms before checking", () => {
    expect(parsePublicUrl("http://2130706433/")).toBeNull();
    expect(parsePublicUrl("http://0x7f.1/")).toBeNull();
  });
  it("rejects non-http, credentials and bad input", () => {
    expect(parsePublicUrl("file:///etc/passwd")).toBeNull();
    expect(parsePublicUrl("https://user:pw@example.com/")).toBeNull();
    expect(parsePublicUrl("not a url")).toBeNull();
    expect(parsePublicUrl("https://example.com/a?b=1")?.hostname).toBe("example.com");
  });
});
