import { createFileRoute } from "@tanstack/react-router";
import { parsePublicUrl } from "@/lib/url-guard";
import { clientIp, limited } from "@/lib/rate-limit";

const MAX_BYTES = 600_000;
const MAX_REDIRECTS = 4;

async function readCapped(res: Response): Promise<string> {
  if (!res.body) return "";
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let out = "";
  let bytes = 0;
  while (bytes < MAX_BYTES) {
    const { done, value } = await reader.read();
    if (done) break;
    bytes += value.byteLength;
    out += dec.decode(value, { stream: true });
  }
  void reader.cancel().catch(() => {});
  return out;
}

// Reads any public web page for ZENKAI (browsers block cross-site reads), returns plain text.
export const Route = createFileRoute("/api/fetch")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        if (limited(`fetch:${clientIp(request)}`, 30, 60_000)) return new Response("rate limited", { status: 429 });
        let u = parsePublicUrl(new URL(request.url).searchParams.get("url") ?? "");
        if (!u) return new Response("blocked url", { status: 400 });
        try {
          let res: Response | null = null;
          // Follow redirects by hand so every hop is checked (a public URL can redirect to 169.254.x.x).
          for (let i = 0; i <= MAX_REDIRECTS; i++) {
            res = await fetch(u, {
              redirect: "manual",
              signal: AbortSignal.timeout(10_000),
              headers: { "User-Agent": "ZENKAI/1.0", Accept: "text/html,application/json,text/plain,*/*" },
            });
            const loc = res.headers.get("location");
            if (res.status >= 300 && res.status < 400 && loc) {
              const next = parsePublicUrl(new URL(loc, u).toString());
              if (!next) return new Response("blocked redirect", { status: 400 });
              u = next;
              res = null;
              continue;
            }
            break;
          }
          if (!res) return new Response("too many redirects", { status: 502 });
          let t = await readCapped(res);
          if ((res.headers.get("content-type") ?? "").includes("html")) {
            t = t.replace(/<(script|style|noscript|svg)[\s\S]*?<\/\1>/gi, "").replace(/<[^>]+>/g, " ")
              .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\s{2,}/g, " ");
          }
          return new Response(t.trim().slice(0, 20000), { status: res.status, headers: { "Content-Type": "text/plain; charset=utf-8" } });
        } catch (e) {
          return new Response(`fetch failed: ${String(e)}`, { status: 502 });
        }
      },
    },
  },
});
