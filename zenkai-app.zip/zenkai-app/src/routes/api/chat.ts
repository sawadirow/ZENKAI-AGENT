import { createFileRoute } from "@tanstack/react-router";
import { clientIp, limited } from "@/lib/rate-limit";

const SYSTEM = `You are ZENKAI, a team of 5 AI agents: Coordinator, Researcher, Planner, Coder, Reviewer.
Think carefully and deeply before answering.
Always start your answer with exactly 4 lines, one per agent, in this format:
@Researcher: <short action, max 6 words>
@Planner: <short action>
@Coder: <short action>
@Reviewer: <short action>
Then a line containing only ---
Then the Coordinator's final answer in markdown, in the same language as the user.

TOOLS (the app executes these automatically):
- You get the FULL contents of every project file with each message. Edit them precisely; never lose existing features.
- Write project files with fenced blocks: \`\`\`html file=index.html, \`\`\`css file=style.css, \`\`\`js file=script.js, \`\`\`python file=main.py. Always send full file contents. Web apps use index.html + style.css + script.js.
- Run shell commands with a \`\`\`bash block, one per line. Available: ls, cat, touch, rm, mv, echo "x" > f, node f.js, js <code>, test, curl <url>, python f.py, py <code>, pip install <pkg> (PyPI via micropip).
- Read websites/docs: send a \`\`\`fetch block with one URL per line. The app fetches them and sends you the text; then continue.
- npm packages: import any package in browser code via ESM, e.g. import confetti from "https://esm.sh/canvas-confetti" inside <script type="module">.
- A Tester agent runs the app after you write files and sends you any errors to fix.
- To change ZENKAI's own interface when the user asks, send a \`\`\`theme block with JSON. You control EVERYTHING visual, not only colors. NEVER say you will "only change colors". Keys:
  * colors (optional): background, foreground, card, primary, primary-foreground, secondary, muted, muted-foreground, accent, border (e.g. "oklch(0.7 0.15 150)").
  * "css" (ALWAYS include for any style request): a full CSS string applied globally to ZENKAI's UI. Use it to restyle everything: fonts (@import url(...) at the top for Google Fonts, then body{font-family:...}), border-radius, shadows, gradients, glassmorphism (backdrop-filter), backgrounds/patterns, spacing, sizes, @keyframes animations, hover/active effects, transitions on all buttons, glow, scrollbars, message bubbles.
    Useful selectors: body, header (top bar), nav (bottom tabs), nav a (tab), nav a[aria-current=page] or nav a.active (active tab), main, button, textarea, img, pre, code, .rounded-2xl (cards/bubbles), .bg-card, .bg-secondary (user bubble), .bg-primary (primary buttons), .border, .prose (AI answer text). Use !important when overriding utility classes.
  * "actions": [{"label":"...","prompt":"..."}] quick buttons above the chat input.
  Make bold, complete redesigns (e.g. Replit style = Replit fonts, radius, panel look, tab style, button motion). The user approves it with one tap.

SECRETS & API KEYS (like Lovable): the user stores keys in the app's Secrets vault. You only ever see the NAMES, never the values.
- If a task needs an API key/token that is not in the available list, send a \`\`\`secret block, one per line: NAME: what it is for (e.g. OPENAI_API_KEY: to call the OpenAI API). The app shows the user a secure input bar and tells you when it is saved. Use UPPER_SNAKE_CASE names.
- NEVER ask the user to paste a key in chat and NEVER write a key value into any file. Python reads secrets with os.environ["NAME"]; the shell with printenv NAME.
- Browser-only apps (index.html/script.js) cannot keep a secret private: use only public/publishable keys there, or tell the user a backend is needed.`;

type Msg = { role: string; content: unknown };
type Meta = { secrets?: { name?: unknown; desc?: unknown }[]; skills?: { title?: unknown; text?: unknown }[] };

// Names/descriptions only. Secret VALUES never reach the AI provider.
function extras(meta: Meta): string {
  const secrets = (Array.isArray(meta.secrets) ? meta.secrets : [])
    .filter((x) => typeof x.name === "string" && /^[A-Z][A-Z0-9_]{1,60}$/.test(x.name))
    .slice(0, 50)
    .map((x) => `- ${x.name}${typeof x.desc === "string" && x.desc ? `: ${x.desc.slice(0, 120)}` : ""}`);
  const skills = (Array.isArray(meta.skills) ? meta.skills : []).slice(0, 10)
    .filter((x) => typeof x.title === "string" && typeof x.text === "string")
    .map((x) => `### ${String(x.title).slice(0, 80)}\n${String(x.text).slice(0, 2000)}`);
  let out = "";
  out += secrets.length ? `\n\nAVAILABLE SECRETS (names only):\n${secrets.join("\n")}` : "\n\nAVAILABLE SECRETS: none yet.";
  if (skills.length) out += `\n\nUSER-DEFINED SKILLS (follow these):\n${skills.join("\n\n")}`;
  return out;
}
type InMsg = { role: string; content: string; images?: string[] };

const PROVIDERS = [
  {
    name: "groq",
    env: "GROQ_API_KEY",
    url: "https://api.groq.com/openai/v1/chat/completions",
    body: (messages: Msg[]) => ({
      model: "openai/gpt-oss-120b",
      messages,
      stream: true,
      reasoning_effort: "high",
      include_reasoning: true,
    }),
  },
  {
    name: "gemini",
    env: "GEMINI_API_KEY",
    url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    body: (messages: Msg[]) => ({
      model: "gemini-2.5-flash",
      messages,
      stream: true,
      reasoning_effort: "high",
    }),
  },
];

// Converts OpenAI chat-completions SSE into the Responses-style events the UI reads.
function translate(body: ReadableStream<Uint8Array>) {
  const enc = new TextEncoder();
  const dec = new TextDecoder();
  let buf = "";
  const emit = (c: TransformStreamDefaultController<Uint8Array>, type: string, delta: string) =>
    c.enqueue(enc.encode(`data: ${JSON.stringify({ type, delta })}\n\n`));
  return body.pipeThrough(
    new TransformStream<Uint8Array, Uint8Array>({
      transform(chunk, c) {
        buf += dec.decode(chunk, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          const s = line.trim();
          if (!s.startsWith("data:")) continue;
          const data = s.slice(5).trim();
          if (data === "[DONE]") continue;
          try {
            const d = JSON.parse(data)?.choices?.[0]?.delta ?? {};
            const r = d.reasoning ?? d.reasoning_content;
            if (r) emit(c, "response.reasoning_summary_text.delta", r);
            if (d.content) emit(c, "response.output_text.delta", d.content);
          } catch {}
        }
      },
    }),
  );
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (limited(`chat:${clientIp(request)}`, 20, 60_000)) return new Response("Too many requests — wait a minute.", { status: 429 });
        let messages: InMsg[];
        let meta: Meta = {};
        try {
          const j = (await request.json()) as { messages?: InMsg[] } & Meta;
          if (!Array.isArray(j.messages) || !j.messages.length) throw new Error("no messages");
          messages = j.messages;
          meta = j;
        } catch {
          return new Response("Bad request", { status: 400 });
        }
        const hasImg = messages.some((m) => m.images?.length);
        const chat: Msg[] = [
          { role: "system", content: SYSTEM + extras(meta) },
          ...messages.slice(-20).map((m) => ({
            role: m.role === "user" ? "user" : "assistant",
            content: m.images?.length
              ? [{ type: "text", text: String(m.content).slice(0, 40000) }, ...m.images.slice(0, 6).map((url) => ({ type: "image_url", image_url: { url } }))]
              : String(m.content).slice(0, 40000),
          })),
        ];
        let lastErr = "No AI key configured";
        let lastStatus = 500;
        // Images need a vision model: use Gemini first.
        const order = hasImg ? [...PROVIDERS].reverse() : PROVIDERS;
        for (const p of order) {
          const key = process.env[p.env];
          if (!key) continue;
          try {
            const res = await fetch(p.url, {
              method: "POST",
              signal: request.signal,
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
              body: JSON.stringify(p.body(chat)),
            });
            if (res.ok && res.body) {
              return new Response(translate(res.body), {
                headers: { "Content-Type": "text/event-stream", "X-Zenkai-Provider": p.name },
              });
            }
            const t = await res.text();
            lastStatus = res.status;
            try {
              const j = JSON.parse(t);
              lastErr = j?.error?.message ?? j?.[0]?.error?.message ?? t;
            } catch {
              lastErr = t;
            }
            lastErr = `${p.name}: ${lastErr}`;
          } catch (e) {
            if (request.signal.aborted) return new Response(null, { status: 499 });
            lastErr = `${p.name}: ${String(e)}`;
          }
        }
        return new Response(lastErr.slice(0, 500), { status: lastStatus });
      },
    },
  },
});
