import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { RotateCw } from "lucide-react";
import { useZ } from "@/lib/zenkai";
import { buildPage } from "@/lib/sandbox";

export const Route = createFileRoute("/preview")({
  head: () => ({
    meta: [
      { title: "Preview — ZENKAI" },
      { name: "description", content: "Live preview of the app your ZENKAI agents built." },
      { property: "og:title", content: "Preview — ZENKAI" },
      { property: "og:description", content: "Live preview of the app your ZENKAI agents built." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PreviewPage,
});

function PreviewPage() {
  const { files } = useZ();
  const [k, setK] = useState(0);
  const page = useMemo(() => buildPage(files), [files]);
  if (!page) return <Empty />;
  return (
    <div className="flex flex-1 flex-col p-3">
      <div className="mb-2 flex items-center gap-2 text-xs text-muted-foreground">
        <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />Running in a safe sandbox
        <button onClick={() => setK(k + 1)} className="ml-auto flex items-center gap-1 rounded-lg border px-2 py-1 transition hover:bg-accent active:scale-90"><RotateCw className="h-3.5 w-3.5" />Reload</button>
      </div>
      <iframe key={k} title="preview" sandbox="allow-scripts allow-forms allow-modals" srcDoc={page} className="animate-pop flex-1 rounded-2xl border bg-card" />
    </div>
  );
}

function Empty() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-center text-muted-foreground">
      <p>Nothing to preview yet.</p>
      <Link to="/" className="rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground transition active:scale-95">Ask ZENKAI to build something</Link>
    </div>
  );
}
