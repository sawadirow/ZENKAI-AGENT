import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useZ } from "@/lib/zenkai";
import { RealTerminal } from "@/components/zenkai/real-terminal";
import { loadTerminalConfig, terminalConfigured, type TerminalConfig } from "@/lib/terminal-config";

export const Route = createFileRoute("/shell")({
  head: () => ({
    meta: [
      { title: "Shell — ZENKAI" },
      { name: "description", content: "Terminal where you and the ZENKAI agents run commands and tests." },
      { property: "og:title", content: "Shell — ZENKAI" },
      { property: "og:description", content: "Terminal where you and the ZENKAI agents run commands and tests." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ShellPage,
});

function ShellPage() {
  const [cfg, setCfg] = useState<TerminalConfig>({ url: "", token: "" });
  const [mode, setMode] = useState<"browser" | "linux">("browser");
  useEffect(() => {
    const c = loadTerminalConfig();
    setCfg(c);
    if (terminalConfigured(c)) setMode("linux");
  }, []);
  const ok = terminalConfigured(cfg);
  const tab = (m: "browser" | "linux", label: string) => (
    <button onClick={() => setMode(m)} className={`rounded-lg px-3 py-1.5 text-xs transition active:scale-95 ${mode === m ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}>{label}</button>
  );
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex gap-1 border-b px-2 py-1.5">{tab("browser", "Browser shell")}{tab("linux", "Real Linux")}</div>
      {mode === "browser" ? <BrowserShell /> : ok ? <RealTerminal cfg={cfg} /> : (
        <div className="m-auto max-w-sm space-y-3 p-6 text-center text-sm text-muted-foreground">
          <p>Real Linux needs your own terminal server.</p>
          <p>Run <code className="rounded bg-secondary px-1">terminal-server/</code> on a VPS, then add its <code className="rounded bg-secondary px-1">wss://</code> URL and token in Settings.</p>
          <Link to="/settings" className="inline-block rounded-full bg-primary px-4 py-2 text-primary-foreground">Open Settings</Link>
        </div>
      )}
    </div>
  );
}

function BrowserShell() {
  const { lines, exec, interrupt } = useZ();
  const [cmd, setCmd] = useState("");
  const [running, setRunning] = useState(false);
  const hist = useRef<string[]>([]);
  const pos = useRef(0);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => end.current?.scrollIntoView(), [lines]);

  const submit = async () => {
    const c = cmd.trim();
    if (!c || running) return;
    hist.current.push(c);
    pos.current = hist.current.length;
    setCmd("");
    setRunning(true);
    try { await exec(c); } finally { setRunning(false); }
  };
  const stop = () => { interrupt(); setRunning(false); };

  return (
    <div dir="ltr" className="flex min-h-0 flex-1 flex-col bg-background font-mono text-xs" onClick={() => document.getElementById("sh")?.focus()}>
      <div className="flex-1 overflow-y-auto p-3 leading-relaxed">
        {lines.length === 0 && <p className="text-muted-foreground">ZENKAI shell — type <span className="text-primary">help</span>. Commands the AI runs appear here too.</p>}
        {lines.map((l, i) => (
          <div key={i} className={`whitespace-pre-wrap ${l.t === "err" ? "text-destructive" : l.t === "in" ? "text-foreground" : "text-muted-foreground"}`}>
            {l.t === "in" && <span className="text-primary">zenkai@project:~$ </span>}{l.s}
          </div>
        ))}
        <div ref={end} />
      </div>
      <form onSubmit={(e) => { e.preventDefault(); void submit(); }} className="flex items-center gap-2 border-t p-3">
        <span className="text-primary">$</span>
        <input id="sh" value={cmd} onChange={(e) => setCmd(e.target.value)} autoCapitalize="off" autoCorrect="off" spellCheck={false}
          onKeyDown={(e) => {
            if (e.ctrlKey && e.key === "c") { e.preventDefault(); stop(); return; }
            if (e.key === "ArrowUp" || e.key === "ArrowDown") {
              e.preventDefault();
              pos.current = Math.max(0, Math.min(hist.current.length, pos.current + (e.key === "ArrowUp" ? -1 : 1)));
              setCmd(hist.current[pos.current] ?? "");
            }
          }}
          className="flex-1 bg-transparent text-base outline-none" placeholder="ls" />
        {running && <button type="button" onClick={stop} className="rounded-lg border px-2 py-1 text-destructive transition active:scale-90">Stop</button>}
      </form>
    </div>
  );
}
