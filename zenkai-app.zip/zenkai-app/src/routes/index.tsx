import { createFileRoute } from "@tanstack/react-router";
import { ChatPanel } from "@/components/zenkai/chat";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ZENKAI — Chat with your AI agent team" },
      { name: "description", content: "Describe an app and ZENKAI's agents write, run, test and fix it." },
      { property: "og:title", content: "ZENKAI — Chat with your AI agent team" },
      { property: "og:description", content: "Describe an app and ZENKAI's agents write, run, test and fix it." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChatPanel,
});
