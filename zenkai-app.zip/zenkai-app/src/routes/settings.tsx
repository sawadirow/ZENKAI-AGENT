import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useZ } from "@/lib/zenkai";
import { loadTerminalConfig, saveTerminalConfig, terminalConfigured } from "@/lib/terminal-config";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — ZENKAI" },
      { name: "description", content: "Manage ZENKAI's style, chat and project data." },
      { property: "og:title", content: "Settings — ZENKAI" },
      { property: "og:description", content: "Manage ZENKAI's style, chat and project data." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { theme, resetTheme, clearChat } = useZ();
  const custom = Object.keys(theme).length > 0;
  const [url, setUrl] = useState("");
  const [token, setToken] = useState("");
  const [saved, setSaved] = useState(false);
  useEffect(() => { const c = loadTerminalConfig(); setUrl(c.url); setToken(c.token); }, []);
  const Row = ({ t, d, a, on }: { t: string; d: string; a: string; on: () => void }) => (
    <div className="animate-fade-up flex items-center gap-3 rounded-2xl border bg-card p-4">
      <div className="flex-1"><p className="font-medium">{t}</p><p className="text-sm text-muted-foreground">{d}</p></div>
      <button onClick={on} className="rounded-xl border px-3 py-2 text-sm transition hover:bg-accent active:scale-95">{a}</button>
    </div>
  );
  return (
    <div className="flex-1 space-y-3 overflow-y-auto p-4">
      <Row t="Style" d={custom ? "Custom style approved from chat" : "Default style. Ask in chat to change it."} a="Reset" on={resetTheme} />
      <Row t="Chat" d="Remove all messages" a="Clear" on={clearChat} />
      <Row t="Project" d="Delete files, chat and shell history" a="Wipe" on={() => { localStorage.removeItem("zenkai"); location.reload(); }} />
      <div className="animate-fade-up space-y-2 rounded-2xl border bg-card p-4">
        <p className="font-medium">Real Linux terminal</p>
        <p className="text-sm text-muted-foreground">Your own server from <code>terminal-server/</code>. Saved on this device only.</p>
        <input dir="ltr" value={url} onChange={(e) => { setUrl(e.target.value); setSaved(false); }} placeholder="wss://terminal.example.com" className="w-full rounded-xl border bg-background px-3 py-2 text-base outline-none focus:border-primary" />
        <input dir="ltr" type="password" value={token} onChange={(e) => { setToken(e.target.value); setSaved(false); }} placeholder="Token" className="w-full rounded-xl border bg-background px-3 py-2 text-base outline-none focus:border-primary" />
        <button onClick={() => { saveTerminalConfig({ url, token }); setSaved(true); }} className="rounded-xl bg-primary px-3 py-2 text-sm text-primary-foreground transition active:scale-95">Save</button>
        {saved && <span className="ml-2 text-xs text-muted-foreground">{terminalConfigured({ url, token }) ? "Saved ✓ — open Shell › Real Linux" : "Saved, but URL must start with ws:// or wss:// and the token must be 8+ characters"}</span>}
      </div>
      <p className="px-1 text-xs text-muted-foreground">AI: Groq (main) · Gemini (backup). Code runs in a safe browser sandbox.</p>
    </div>
  );
}
