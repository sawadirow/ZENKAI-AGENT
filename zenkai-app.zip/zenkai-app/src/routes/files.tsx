import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { FileText, FilePlus, Trash2 } from "lucide-react";
import { useZ } from "@/lib/zenkai";

export const Route = createFileRoute("/files")({
  head: () => ({
    meta: [
      { title: "Files — ZENKAI" },
      { name: "description", content: "All files in your ZENKAI project." },
      { property: "og:title", content: "Files — ZENKAI" },
      { property: "og:description", content: "All files in your ZENKAI project." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FilesPage,
});

function FilesPage() {
  const { files, setFile, delFile } = useZ();
  const [name, setName] = useState("");
  const names = Object.keys(files).sort();
  return (
    <div className="flex-1 overflow-y-auto p-3">
      <form onSubmit={(e) => { e.preventDefault(); if (name.trim()) { setFile(name.trim(), ""); setName(""); } }} className="mb-3 flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="new-file.js" dir="ltr" className="flex-1 rounded-xl border bg-card px-3 py-2 text-base outline-none focus:border-primary" />
        <button className="flex items-center gap-1 rounded-xl bg-primary px-3 text-sm text-primary-foreground transition active:scale-95"><FilePlus className="h-4 w-4" />Add</button>
      </form>
      {names.length === 0 && <p className="p-6 text-center text-muted-foreground">No files yet.</p>}
      <ul className="space-y-1.5">
        {names.map((n, i) => (
          <li key={n} className="animate-slide-in flex items-center gap-3 rounded-xl border bg-card px-3 py-2.5" style={{ animationDelay: `${i * 40}ms` }}>
            <FileText className="h-4 w-4 text-primary" />
            <Link to="/code" className="flex-1 truncate text-sm" dir="ltr">{n}</Link>
            <span className="text-xs text-muted-foreground">{files[n]!.length} B</span>
            <button aria-label={`Delete ${n}`} onClick={() => delFile(n)} className="rounded-lg p-1.5 text-muted-foreground transition hover:bg-accent hover:text-destructive active:scale-90"><Trash2 className="h-4 w-4" /></button>
          </li>
        ))}
      </ul>
    </div>
  );
}
