import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useZ } from "@/lib/zenkai";

export const Route = createFileRoute("/code")({
  head: () => ({
    meta: [
      { title: "Code — ZENKAI" },
      { name: "description", content: "Read and edit the code your ZENKAI agents wrote." },
      { property: "og:title", content: "Code — ZENKAI" },
      { property: "og:description", content: "Read and edit the code your ZENKAI agents wrote." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CodePage,
});

function CodePage() {
  const { files, setFile } = useZ();
  const names = Object.keys(files).sort();
  const [sel, setSel] = useState<string | null>(null);
  const cur = sel && files[sel] != null ? sel : names[0];
  if (!cur) return <p className="m-auto p-6 text-center text-muted-foreground">No code yet. Ask in Chat.</p>;
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex gap-1 overflow-x-auto border-b px-2 py-2 [scrollbar-width:none]">
        {names.map((n) => (
          <button key={n} onClick={() => setSel(n)} className={`shrink-0 rounded-lg px-3 py-1.5 text-xs transition active:scale-95 ${n === cur ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}>{n}</button>
        ))}
      </div>
      <textarea key={cur} dir="ltr" spellCheck={false} value={files[cur]} onChange={(e) => setFile(cur, e.target.value)}
        className="animate-fade-up flex-1 resize-none bg-background p-4 font-mono text-xs leading-relaxed outline-none" />
    </div>
  );
}
