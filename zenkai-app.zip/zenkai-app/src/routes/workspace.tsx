import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { FilePlus, FileText, Monitor, Pencil, Search, Trash2, X } from "lucide-react";
import { useZ } from "@/lib/zenkai";
import { ChatPanel } from "@/components/zenkai/chat";

export const Route = createFileRoute("/workspace")({
  head: () => ({
    meta: [
      { title: "Workspace — ZENKAI" },
      { name: "description", content: "Files, code editor and AI agent side by side in ZENKAI." },
      { property: "og:title", content: "Workspace — ZENKAI" },
      { property: "og:description", content: "Files, code editor and AI agent side by side in ZENKAI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Workspace,
});

function Workspace() {
  const { files, setFile, delFile } = useZ();
  const [q, setQ] = useState("");
  const [tabs, setTabs] = useState<string[]>([]);
  const [cur, setCur] = useState<string | null>(null);
  const names = Object.keys(files).sort().filter((n) => n.toLowerCase().includes(q.toLowerCase()));
  const open = tabs.filter((t) => files[t] != null);
  const active = cur && files[cur] != null ? cur : open[0] ?? null;
  const openFile = (n: string) => { setTabs((t) => (t.includes(n) ? t : [...t, n])); setCur(n); };
  const close = (n: string) => { setTabs((t) => t.filter((x) => x !== n)); if (cur === n) setCur(null); };
  const add = () => { const n = prompt("File name", "new.js")?.trim(); if (n) { setFile(n, files[n] ?? ""); openFile(n); } };
  const rename = (n: string) => {
    const m = prompt("Rename", n)?.trim(); if (!m || m === n) return;
    setFile(m, files[n]!); delFile(n); setTabs((t) => t.map((x) => (x === n ? m : x))); if (cur === n) setCur(m);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
      <aside className="flex max-h-48 shrink-0 flex-col border-b lg:max-h-none lg:w-60 lg:border-b-0 lg:border-r">
        <div className="flex items-center gap-1 p-2">
          <div className="flex flex-1 items-center gap-1.5 rounded-lg border bg-card px-2">
            <Search className="h-3.5 w-3.5 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search files" className="w-full bg-transparent py-1.5 text-sm outline-none" />
          </div>
          <button aria-label="New file" onClick={add} className="rounded-lg p-2 transition hover:bg-accent active:scale-90"><FilePlus className="h-4 w-4" /></button>
        </div>
        <ul className="flex-1 overflow-y-auto px-1 pb-2">
          {names.length === 0 && <li className="p-4 text-center text-xs text-muted-foreground">No files yet</li>}
          {names.map((n) => (
            <li key={n} className={`group flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm transition ${n === active ? "bg-secondary" : "hover:bg-accent"}`}>
              <FileText className="h-3.5 w-3.5 shrink-0 text-primary" />
              <button dir="ltr" onClick={() => openFile(n)} className="flex-1 truncate text-left">{n}</button>
              <button aria-label={`Rename ${n}`} onClick={() => rename(n)} className="text-muted-foreground opacity-60 hover:opacity-100"><Pencil className="h-3.5 w-3.5" /></button>
              <button aria-label={`Delete ${n}`} onClick={() => { delFile(n); close(n); }} className="text-muted-foreground opacity-60 hover:text-destructive hover:opacity-100"><Trash2 className="h-3.5 w-3.5" /></button>
            </li>
          ))}
        </ul>
      </aside>

      <section className="flex min-h-0 min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-1 overflow-x-auto border-b px-2 py-1.5 [scrollbar-width:none]">
          {open.map((n) => (
            <span key={n} className={`flex shrink-0 items-center gap-1 rounded-lg px-2.5 py-1 text-xs transition ${n === active ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              <button dir="ltr" onClick={() => setCur(n)}>{n}</button>
              <button aria-label={`Close ${n}`} onClick={() => close(n)} className="opacity-60 hover:opacity-100"><X className="h-3 w-3" /></button>
            </span>
          ))}
          <Link to="/preview" className="ml-auto flex shrink-0 items-center gap-1 rounded-lg px-2.5 py-1 text-xs text-muted-foreground transition hover:bg-accent hover:text-foreground"><Monitor className="h-3.5 w-3.5" />Preview</Link>
        </div>
        {active ? (
          <textarea key={active} dir="ltr" spellCheck={false} value={files[active]} onChange={(e) => setFile(active, e.target.value)}
            className="animate-fade-up flex-1 resize-none bg-background p-4 font-mono text-xs leading-relaxed outline-none" />
        ) : <p className="m-auto p-6 text-center text-sm text-muted-foreground">Pick a file to edit — changes save automatically.</p>}
      </section>

      <aside className="hidden min-h-0 w-[400px] shrink-0 flex-col border-l lg:flex">
        <ChatPanel />
      </aside>
    </div>
  );
}
