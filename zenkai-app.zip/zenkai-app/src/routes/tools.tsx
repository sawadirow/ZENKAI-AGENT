import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { ALL_TOOLS, GROUPS, STATUS_LABEL } from "@/components/zenkai/tools/registry";

export const Route = createFileRoute("/tools")({
  validateSearch: (s: Record<string, unknown>): { p?: string | undefined } => ({ p: typeof s["p"] === "string" ? s["p"] : undefined }),
  head: () => ({
    meta: [
      { title: "Tools — ZENKAI" },
      { name: "description", content: "Publishing, secrets, git, security and more for your ZENKAI project." },
      { property: "og:title", content: "Tools — ZENKAI" },
      { property: "og:description", content: "Publishing, secrets, git, security and more for your ZENKAI project." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ToolsPage,
});

function ToolsPage() {
  const { p } = Route.useSearch();
  const nav = useNavigate();
  const tool = ALL_TOOLS.find((t) => t.id === p);

  if (tool && "Panel" in tool) {
    const { Panel, title, Icon } = tool;
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <div className="flex items-center gap-2 border-b px-3 py-2">
          <button aria-label="Back to tools" onClick={() => void nav({ to: "/tools", search: {} })} className="rounded-lg p-2 hover:bg-accent"><ArrowLeft className="h-5 w-5" /></button>
          <Icon className="h-4 w-4 text-primary" /><span className="font-medium">{title}</span>
        </div>
        <div key={tool.id} className="animate-rise flex min-h-0 flex-1 flex-col"><Panel /></div>
      </div>
    );
  }

  let i = 0;
  return (
    <div className="flex-1 space-y-5 overflow-y-auto px-4 py-4">
      {GROUPS.map((g) => (
        <section key={g.name}>
          <h2 className="mb-2 px-1 text-sm font-medium text-muted-foreground">{g.name}</h2>
          <div className="space-y-2">
            {g.tools.map((t) => {
              const body = (
                <>
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary"><t.Icon className="h-5 w-5" /></span>
                  <span className="min-w-0 flex-1 text-left">
                    <span className="block font-medium">{t.title}</span>
                    <span className="block truncate text-xs text-muted-foreground">{t.desc}</span>
                  </span>
                  {STATUS_LABEL[t.status] && <span className="shrink-0 rounded-full bg-secondary px-2 py-0.5 text-[10px] text-muted-foreground">{STATUS_LABEL[t.status]}</span>}
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                </>
              );
              const cls = "animate-rise flex items-center gap-3 rounded-2xl border bg-card p-3 transition hover:border-primary/50 active:scale-[.98]";
              const style = { animationDelay: `${i++ * 35}ms` };
              return "to" in t
                ? <Link key={t.id} to={t.to} className={cls} style={style}>{body}</Link>
                : <Link key={t.id} to="/tools" search={{ p: t.id }} className={cls} style={style}>{body}</Link>;
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
