import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import { buildPage, runJs, runSandbox } from "./sandbox";
import { killPy, runPy } from "./pyworker";
import { KEYS, readStore, secretEnv, validSecretName, writeStore, type Secret, type Skill } from "./store";

export type Step = { icon: "read" | "edit" | "search" | "run"; label: string; done: boolean; agent: string; fail?: boolean; file?: string; code?: string };
export type Msg = {
  id: number; role: "user" | "ai"; text: string; thinking?: boolean;
  thoughtSecs?: number | undefined; thoughts?: string | undefined; steps?: Step[];
  theme?: Record<string, unknown>; themeState?: "pending" | "applied" | "rejected";
  hidden?: boolean; images?: string[];
  secretReqs?: { name: string; desc: string; state: "pending" | "saved" | "skipped" }[];
};
export type Action = { label: string; prompt: string };
export type Line = { t: "in" | "out" | "err"; s: string };

export const THEME_KEYS = ["background", "foreground", "card", "primary", "primary-foreground", "secondary", "muted", "muted-foreground", "accent", "border"];

const LANG_FILE: Record<string, string> = { html: "index.html", css: "style.css", js: "script.js", javascript: "script.js" };

export function parseBlocks(text: string) {
  const out: { lang: string; file?: string | undefined; code: string }[] = [];
  for (const x of text.matchAll(/```([\w-]*)[^\S\n]*(?:file=)?([\w./-]*\.\w+)?[^\n]*\n([\s\S]*?)```/g)) {
    out.push({ lang: (x[1] ?? "").toLowerCase(), file: x[2] || undefined, code: x[3] ?? "" });
  }
  return out;
}

type Ctx = {
  msgs: Msg[]; busy: boolean; files: Record<string, string>; lines: Line[]; theme: Record<string, string>; actions: Action[];
  send: (t: string, images?: string[]) => void; stop: () => void;
  exec: (cmd: string) => Promise<void>; interrupt: () => void;
  saveSecret: (msgId: number, name: string, value: string) => void; skipSecret: (msgId: number, name: string) => void;
  setFile: (p: string, c: string) => void; delFile: (p: string) => void;
  decideTheme: (id: number, ok: boolean) => void; resetTheme: () => void; clearChat: () => void;
};
async function webFetch(url: string) {
  try { const r = await fetch(`/api/fetch?url=${encodeURIComponent(url)}`); return await r.text(); } catch (e) { return `fetch failed: ${String(e)}`; }
}
// Keep one context across hot reloads so already-mounted screens never lose the provider.
const g = globalThis as unknown as { __zenkaiCtx?: React.Context<Ctx | null> };
const C = (g.__zenkaiCtx ??= createContext<Ctx | null>(null));
export const useZ = () => { const c = useContext(C); if (!c) throw new Error("ZenkaiProvider missing"); return c; };

export function ZenkaiProvider({ children }: { children: React.ReactNode }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [busy, setBusy] = useState(false);
  const [files, setFiles] = useState<Record<string, string>>({});
  const [lines, setLines] = useState<Line[]>([]);
  const [theme, setTheme] = useState<Record<string, string>>({});
  const [actions, setActions] = useState<Action[]>([]);
  const filesRef = useRef(files); filesRef.current = files;
  const msgsRef = useRef(msgs); msgsRef.current = msgs;
  const abortRef = useRef<AbortController | null>(null);
  const loaded = useRef(false);

  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem("zenkai") ?? "{}");
      if (s.files) setFiles(s.files); if (s.theme) setTheme(s.theme); if (s.msgs) setMsgs(s.msgs); if (s.lines) setLines(s.lines); if (s.actions) setActions(s.actions);
    } catch {}
    loaded.current = true;
  }, []);
  useEffect(() => {
    if (!loaded.current || busy) return;
    // Images are base64 and can blow the ~5MB localStorage quota, so they are not persisted.
    const slim = msgs.slice(-60).map(({ images: _images, ...m }) => m);
    const save = (payload: object) => localStorage.setItem("zenkai", JSON.stringify(payload));
    try { save({ files, theme, msgs: slim, lines: lines.slice(-200), actions }); }
    catch { try { save({ files, theme, msgs: slim.slice(-10), lines: [], actions }); } catch { /* storage full or blocked */ } }
  }, [files, theme, msgs, lines, busy, actions]);
  useEffect(() => {
    const r = document.documentElement;
    THEME_KEYS.forEach((k) => (theme[k] ? r.style.setProperty(`--${k}`, theme[k]!) : r.style.removeProperty(`--${k}`)));
    let el = document.getElementById("zenkai-css");
    if (!el) { el = document.createElement("style"); el.id = "zenkai-css"; document.head.appendChild(el); }
    el.textContent = theme["css"] ?? "";
  }, [theme]);

  const print = (t: Line["t"], s: string) => setLines((p) => [...p, ...s.split("\n").map((x) => ({ t, s: x }))]);
  const setFile = (p: string, c: string) => setFiles((f) => ({ ...f, [p]: c }));
  const delFile = (p: string) => setFiles((f) => { const n = { ...f }; delete n[p]; return n; });

  const exec = async (raw: string) => {
    const cmd = raw.trim(); if (!cmd) return;
    print("in", cmd);
    const [c, ...a] = cmd.split(/\s+/); const arg = a.join(" "); const fs = filesRef.current;
    const echo = cmd.match(/^echo\s+(["']?)([\s\S]*?)\1\s*(>>?)\s*(\S+)$/);
    if (echo) { const [, , txt, op, p] = echo; setFile(p!, (op === ">>" ? (fs[p!] ?? "") + "\n" : "") + txt); return; }
    switch (c) {
      case "help": return print("out", "ls · cat · touch · rm · mv · echo txt > f · node f.js · js <code> · test · curl <url> · python f.py · py <code> · pip install <pkg> · clear · pwd · whoami · date · env · printenv NAME");
      case "curl": case "wget": case "fetch": {
        const url = a.find((x) => /^https?:/.test(x)); if (!url) return print("err", "curl: give a URL");
        const t = await webFetch(url); return print("out", t.slice(0, 4000));
      }
      case "python": case "python3": case "py": case "pip": case "pip3": {
        const on = { out: (x: string) => print("out", x), err: (x: string) => print("err", x),
          files: (f: Record<string, string>) => Object.entries(f).forEach(([k, v]) => setFile(k, v)) };
        if (c.startsWith("pip")) {
          const pk = a.filter((x) => x !== "install" && !x.startsWith("-"));
          if (!pk.length || pk.some((x) => !/^[\w.\-[\]=<>~!,]+$/.test(x))) return print("err", "pip: usage: pip install <package>");
          print("out", "… installing (first run loads Python, ~10s)");
          await runPy({ pkgs: pk }, on);
          return;
        }
        const code = c === "py" ? arg : fs[arg];
        if (!code) return print("err", c === "py" ? "py: give some code" : `python: ${arg || "(no file)"}: No such file`);
        print("out", "… running (Ctrl+C or Stop to cancel)");
        const rc = await runPy({ code, files: fs, env: secretEnv() }, on);
        return print(rc === 0 ? "out" : "err", rc === 0 ? "✓ exited with code 0" : `✗ exited with code ${rc}`);
      }
      case "ls": return print("out", Object.keys(fs).sort().join("  ") || "(empty)");
      case "cat": return fs[arg] != null ? print("out", fs[arg]!) : print("err", `cat: ${arg}: No such file`);
      case "touch": return setFile(arg, fs[arg] ?? "");
      case "rm": return fs[arg] != null ? delFile(arg) : print("err", `rm: ${arg}: No such file`);
      case "mv": { const [x, y] = a; if (!x || !y || fs[x] == null) return print("err", "mv: bad args"); setFiles((f) => { const n = { ...f, [y]: f[x]! }; delete n[x]; return n; }); return; }
      case "env": { const all = readStore<Secret[]>(KEYS.secrets, []); return print("out", all.length ? all.map((x) => `${x.name}=${"*".repeat(8)}`).join("\n") : "(no secrets — add them in Tools › Secrets)"); }
      case "printenv": { const v = readStore<Secret[]>(KEYS.secrets, []).find((x) => x.name === arg)?.value; return v != null ? print("out", v) : print("err", `printenv: ${arg || "(name)"}: not set`); }
      case "pwd": return print("out", "/home/zenkai/project");
      case "whoami": return print("out", "zenkai");
      case "date": return print("out", new Date().toString());
      case "clear": return setLines([]);
      case "node": case "js": {
        const code = c === "node" ? fs[arg] : arg;
        if (code == null) return print("err", `node: ${arg}: No such file`);
        const r = await runJs(code); r.logs.forEach((l) => print("out", l)); r.errors.forEach((l) => print("err", l));
        return print("out", r.errors.length ? `✗ exited with code 1` : `✓ exited with code 0`);
      }
      case "npm": case "npx": return print("err", `${c}: not available in the browser shell. Import packages as ESM instead, e.g. import x from "https://esm.sh/<package>"`);
      case "test": {
        const page = buildPage(fs); if (!page) return print("err", "nothing to run — no index.html or script.js");
        const r = await runSandbox(page); r.logs.forEach((l) => print("out", l)); r.errors.forEach((l) => print("err", l));
        return print("out", r.errors.length ? `✗ ${r.errors.length} error(s)` : "✓ app ran with 0 errors");
      }
      default: return print("err", `${c}: command not found (type help)`);
    }
  };

  const update = (id: number, fn: (m: Msg) => Msg) => setMsgs((p) => p.map((m) => (m.id === id ? fn(m) : m)));

  const ask = async (text: string, round: number, hidden = false, images: string[] = []) => {
    setBusy(true);
    const id = Date.now();
    const history: { role: string; content: string; images?: string[] }[] = [...msgsRef.current.filter((m) => m.text).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.text })), { role: "user", content: text || "(see image)", images }];
    const fileCtx = Object.keys(filesRef.current).length ? `\n\n[Project files — full contents]\n` + Object.entries(filesRef.current).map(([p, c]) => `--- ${p} ---\n${c.slice(0, 12000)}`).join("\n") : "";
    history[history.length - 1]!.content += fileCtx;
    setMsgs((p) => [...p, { id: id - 1, role: "user", text, hidden, images }, { id, role: "ai", text: "", thinking: true, steps: [] }]);
    const started = Date.now(); const ctrl = new AbortController(); abortRef.current = ctrl;
    let thoughts = "", raw = "";
    const icons: Step["icon"][] = ["search", "read", "edit", "run"];
    const render = (final = false) => {
      const sep = raw.indexOf("\n---");
      const head = sep >= 0 ? raw.slice(0, sep) : raw;
      const body = sep >= 0 ? raw.slice(sep + 4).replace(/^-*\n?/, "").trimStart() : (head.trim() && !head.trim().startsWith("@") ? raw : "");
      const ls = head.split("\n").filter((l) => l.startsWith("@") && l.includes(":"));
      const steps: Step[] = ls.map((l, i) => { const [a, ...r] = l.slice(1).split(":"); return { agent: (a ?? "").trim(), label: r.join(":").trim(), icon: icons[i % 4] ?? "search", done: final || sep >= 0 || i < ls.length - 1 }; });
      update(id, (m) => ({ ...m, steps, text: body, thoughts: thoughts || m.thoughts, thinking: !raw && !final,
        thoughtSecs: raw || final ? m.thoughtSecs ?? Math.max(1, Math.round((Date.now() - started) / 1000)) : undefined }));
      return body;
    };
    let body = "";
    try {
      const res = await fetch("/api/chat", { method: "POST", signal: ctrl.signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify({
        messages: history,
        secrets: readStore<Secret[]>(KEYS.secrets, []).map(({ name, desc }) => ({ name, desc })),
        skills: readStore<Skill[]>(KEYS.skills, []).filter((k) => k.on).map(({ title, text }) => ({ title, text })),
      }) });
      if (!res.ok || !res.body) throw new Error((await res.text()) || `Error ${res.status}`);
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "";
      while (true) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true }); const parts = buf.split("\n"); buf = parts.pop() ?? "";
        for (const line of parts) {
          if (!line.startsWith("data:")) continue;
          try { const ev = JSON.parse(line.slice(5).trim());
            if (ev.type === "response.reasoning_summary_text.delta") thoughts += ev.delta; else if (ev.type === "response.output_text.delta") raw += ev.delta; else continue;
            render(); } catch {}
        }
      }
      body = render(true);
    } catch (e) {
      if (!ctrl.signal.aborted) update(id, (m) => ({ ...m, thinking: false, text: `⚠️ ${(e as Error).message}` })); else render(true);
      abortRef.current = null; setBusy(false); return;
    }
    abortRef.current = null;

    // Apply files, theme proposal, and shell commands from the reply.
    const blocks = parseBlocks(body); let n = 0; const newFiles = { ...filesRef.current }; const cmds: string[] = []; const fileSteps: Step[] = []; const urls: string[] = [];
    const reqs: NonNullable<Msg["secretReqs"]> = [];
    for (const b of blocks) {
      if (b.lang === "secret") {
        const have = new Set(readStore<Secret[]>(KEYS.secrets, []).map((x) => x.name));
        for (const line of b.code.split("\n")) {
          const [rawName, ...rest] = line.split(":");
          const name = (rawName ?? "").trim().toUpperCase();
          if (validSecretName(name) && !have.has(name) && !reqs.some((r) => r.name === name)) reqs.push({ name, desc: rest.join(":").trim().slice(0, 140), state: "pending" });
        }
        continue;
      }
      if (b.lang === "fetch") { urls.push(...b.code.split("\n").map((s) => s.trim()).filter((s) => /^https?:/.test(s))); continue; }
      if (b.lang === "theme") { try { const t = JSON.parse(b.code); update(id, (m) => ({ ...m, theme: t, themeState: "pending" })); } catch {} continue; }
      if (/^(bash|sh|shell|zsh|console|terminal)$/.test(b.lang)) { cmds.push(...b.code.split("\n").map((s) => s.replace(/^\$\s*/, "")).filter(Boolean)); continue; }
      const p = b.file ?? LANG_FILE[b.lang] ?? `snippet-${++n}.${b.lang || "txt"}`;
      const existed = filesRef.current[p] != null;
      newFiles[p] = b.code;
      fileSteps.push({ agent: "Coder", label: `${existed ? "Edited" : "Created"} ${p}`, icon: "edit", done: true, file: p, code: b.code });
    }
    if (cmds.length) fileSteps.push({ agent: "Shell", label: `Ran ${cmds.length} command${cmds.length > 1 ? "s" : ""}`, icon: "run", done: true, file: "terminal", code: cmds.map((c) => "$ " + c).join("\n") });
    if (reqs.length) fileSteps.push({ agent: "Secrets", label: `Needs ${reqs.map((r) => r.name).join(", ")}`, icon: "search", done: true });
    if (reqs.length) update(id, (m) => ({ ...m, secretReqs: reqs }));
    if (fileSteps.length) update(id, (m) => ({ ...m, steps: [...(m.steps ?? []), ...fileSteps] }));
    filesRef.current = newFiles; setFiles(newFiles);
    if (urls.length && round < 3) {
      update(id, (m) => ({ ...m, steps: [...(m.steps ?? []), ...urls.map((u) => ({ agent: "Researcher", label: `Read ${u.replace(/^https?:\/\//, "").slice(0, 50)}`, icon: "search" as const, done: true }))] }));
      const pages = await Promise.all(urls.slice(0, 4).map(async (u) => `--- ${u} ---\n${(await webFetch(u)).slice(0, 8000)}`));
      setBusy(false); return ask(`Here are the fetched pages. Continue the task:\n${pages.join("\n")}`, round + 1, true);
    }
    for (const c of cmds) await exec(c);

    // Tester agent: actually runs the app and auto-fixes errors.
    const page = buildPage(newFiles);
    if (page && blocks.some((b) => !["theme", "bash", "sh", "shell"].includes(b.lang))) {
      update(id, (m) => ({ ...m, steps: [...(m.steps ?? []), { agent: "Tester", label: "Running the app…", icon: "run", done: false }] }));
      print("in", "test"); const r = await runSandbox(page);
      r.logs.forEach((l) => print("out", l)); r.errors.forEach((l) => print("err", l));
      const ok = !r.errors.length;
      print("out", ok ? "✓ app ran with 0 errors" : `✗ ${r.errors.length} error(s)`);
      update(id, (m) => ({ ...m, steps: (m.steps ?? []).map((s) => s.agent === "Tester" ? { ...s, done: true, fail: !ok, label: ok ? "Ran the app · 0 errors" : `Found ${r.errors.length} error(s)` } : s) }));
      if (!ok && round < 2) { setBusy(false); return ask(`The Tester ran the app and found these errors. Fix them and resend the full corrected files:\n${r.errors.join("\n")}`, round + 1, true); }
    }
    setBusy(false);
  };

  const resolveSecret = (msgId: number, name: string, state: "saved" | "skipped") => {
    const m = msgsRef.current.find((x) => x.id === msgId);
    if (!m) return;
    const reqs = (m.secretReqs ?? []).map((r) => (r.name === name ? { ...r, state } : r));
    update(msgId, (x) => ({ ...x, secretReqs: reqs }));
    if (busy || reqs.some((r) => r.state === "pending")) return;
    const saved = reqs.filter((r) => r.state === "saved").map((r) => r.name);
    void ask(saved.length ? `Secret(s) saved: ${saved.join(", ")}. Continue the task.` : "I skipped the secret request. Continue without it if possible.", 0, true);
  };

  const value: Ctx = {
    msgs, busy, files, lines, theme,
    send: (t, imgs = []) => { if ((t.trim() || imgs.length) && !busy) void ask(t.trim(), 0, false, imgs); },
    stop: () => abortRef.current?.abort(),
    exec, interrupt: () => killPy(), setFile, delFile,
    saveSecret: (msgId, name, val) => {
      const v = val.trim();
      if (!validSecretName(name) || !v) return;
      const m = msgsRef.current.find((x) => x.id === msgId);
      const desc = m?.secretReqs?.find((r) => r.name === name)?.desc;
      const rest = readStore<Secret[]>(KEYS.secrets, []).filter((x) => x.name !== name);
      if (!writeStore(KEYS.secrets, [...rest, { name, value: v, desc }])) { print("err", "could not save secret (browser storage full or blocked)"); return; }
      resolveSecret(msgId, name, "saved");
    },
    skipSecret: (msgId, name) => resolveSecret(msgId, name, "skipped"),
    decideTheme: (id, ok) => {
      const m = msgs.find((x) => x.id === id);
      if (ok && m?.theme) {
        const th = m.theme as Record<string, unknown>;
        setTheme((t) => ({ ...t, ...Object.fromEntries(Object.entries(th).filter(([k, v]) => (THEME_KEYS.includes(k) || k === "css") && typeof v === "string")) as Record<string, string> }));
        if (Array.isArray(th["actions"])) setActions((th["actions"] as Action[]).filter((x) => x?.label && x?.prompt).slice(0, 8));
      }
      update(id, (x) => ({ ...x, themeState: ok ? "applied" : "rejected" }));
    },
    resetTheme: () => { setTheme({}); setActions([]); },
    actions,
    clearChat: () => setMsgs([]),
  };
  return <C.Provider value={value}>{children}</C.Provider>;
}
