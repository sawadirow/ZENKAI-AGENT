// Where the real-Linux terminal server lives (see /terminal-server). Stored on this device only.
export type TerminalConfig = { url: string; token: string };
const KEY = "zenkai-terminal";

export function loadTerminalConfig(): TerminalConfig {
  try {
    const c = JSON.parse(localStorage.getItem(KEY) ?? "{}") as Partial<TerminalConfig>;
    return { url: c.url ?? "", token: c.token ?? "" };
  } catch { return { url: "", token: "" }; }
}
export function saveTerminalConfig(c: TerminalConfig) {
  localStorage.setItem(KEY, JSON.stringify({ url: c.url.trim(), token: c.token.trim() }));
}
export const terminalConfigured = (c: TerminalConfig) => /^wss?:\/\//.test(c.url) && c.token.length >= 8;
