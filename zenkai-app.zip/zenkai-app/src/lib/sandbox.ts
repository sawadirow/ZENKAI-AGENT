// Runs HTML/JS inside an isolated, script-only iframe and collects console output + errors.
export type RunResult = { logs: string[]; errors: string[] };

const hook = (nonce: string) => `<script>(function(){
const N=${JSON.stringify(nonce)};
const send=(k,a)=>{try{parent.postMessage({__zk:N,k,m:a.map(x=>{try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(' ')},'*')}catch(e){}};
['log','info','warn','error'].forEach(k=>{const o=console[k];console[k]=(...a)=>{send(k==='error'?'error':'log',a);o.apply(console,a)}});
addEventListener('error',e=>send('error',[e.message+(e.lineno?' (line '+e.lineno+')':'')]));
addEventListener('unhandledrejection',e=>send('error',['Unhandled promise: '+(e.reason&&e.reason.message||e.reason)]));
})();<\/script>`;

export function withHook(html: string, nonce = "0") {
  const HOOK = hook(nonce);
  return /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => m + HOOK) : HOOK + html;
}

export function buildPage(files: Record<string, string>) {
  let html = files["index.html"] ?? "";
  const css = files["style.css"], js = files["script.js"];
  if (!html && !js) return "";
  if (!html) html = "<!doctype html><html><head></head><body></body></html>";
  html = html.replace(/<link[^>]*href=["']\.?\/?style\.css["'][^>]*>/gi, "").replace(/<script[^>]*src=["']\.?\/?script\.js["'][^>]*>\s*<\/script>/gi, "");
  if (css) html = html.includes("</head>") ? html.replace("</head>", `<style>${css}</style></head>`) : `<style>${css}</style>` + html;
  if (js) html = html.includes("</body>") ? html.replace("</body>", `<script>${js}<\/script></body>`) : html + `<script>${js}<\/script>`;
  return html;
}

export function runSandbox(html: string, ms = 2500): Promise<RunResult> {
  const nonce = crypto.randomUUID();
  return new Promise((resolve) => {
    const logs: string[] = [], errors: string[] = [];
    const f = document.createElement("iframe");
    f.setAttribute("sandbox", "allow-scripts");
    f.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;left:-9999px";
    const on = (e: MessageEvent) => {
      if (e.source !== f.contentWindow || e.data?.__zk !== nonce) return;
      (e.data.k === "error" ? errors : logs).push(String(e.data.m));
    };
    window.addEventListener("message", on);
    f.srcdoc = withHook(html, nonce);
    document.body.appendChild(f);
    setTimeout(() => { window.removeEventListener("message", on); f.remove(); resolve({ logs, errors }); }, ms);
  });
}

export const runJs = (code: string, ms = 1500) => runSandbox(`<script>${code}<\/script>`, ms);
