// Tiny localStorage store shared by the Tools panels and the AI loop.
import { useCallback, useEffect, useState } from "react";

export type Secret = { name: string; value: string; desc?: string | undefined };
export type Skill = { id: string; title: string; text: string; on: boolean };
export type Checkpoint = { id: string; msg: string; at: number; files: Record<string, string> };
export type Workflow = { id: string; name: string; cmds: string[] };

export const KEYS = {
  secrets: "zenkai-secrets",
  skills: "zenkai-skills",
  checkpoints: "zenkai-checkpoints",
  workflows: "zenkai-workflows",
} as const;

const EVT = "zenkai-store";

export function readStore<T>(key: string, init: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : init;
  } catch { return init; }
}

export function writeStore<T>(key: string, v: T): boolean {
  try { localStorage.setItem(key, JSON.stringify(v)); }
  catch { return false; } // quota full or storage blocked
  window.dispatchEvent(new CustomEvent(EVT, { detail: key }));
  return true;
}

export const newId = () => Math.random().toString(36).slice(2, 10);
export const validSecretName = (n: string) => /^[A-Z][A-Z0-9_]{1,60}$/.test(n);
export const secretEnv = (): Record<string, string> =>
  Object.fromEntries(readStore<Secret[]>(KEYS.secrets, []).map((s) => [s.name, s.value]));

/** SSR-safe: starts with `init`, loads the saved value after mount, and stays in sync across panels. */
export function useStored<T>(key: string, init: T): [T, (v: T | ((p: T) => T)) => boolean] {
  const [val, setVal] = useState<T>(init);
  useEffect(() => {
    const load = () => setVal(readStore(key, init));
    load();
    const h = (e: Event) => { if ((e as CustomEvent).detail === key) load(); };
    window.addEventListener(EVT, h);
    return () => window.removeEventListener(EVT, h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  const set = useCallback((v: T | ((p: T) => T)) => {
    const next = typeof v === "function" ? (v as (p: T) => T)(readStore(key, init)) : v;
    return writeStore(key, next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return [val, set];
}
