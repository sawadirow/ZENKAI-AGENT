// Main-thread side of the Python worker (public/py-worker.js).
type Handlers = { out: (s: string) => void; err: (s: string) => void; files: (f: Record<string, string>) => void };
type Job = { pkgs: string[] } | { code: string; files: Record<string, string>; env?: Record<string, string> };

let worker: Worker | null = null;
let cancel: (() => void) | null = null;
let seq = 0;

/** Stops the running script (and frees memory). Installed packages are reloaded on next run. */
export function killPy() {
  worker?.terminate();
  worker = null;
  cancel?.();
  cancel = null;
}

export function runPy(job: Job, on: Handlers, timeoutMs = 60_000): Promise<number> {
  worker ??= new Worker("/py-worker.js");
  const w = worker;
  const id = ++seq;
  return new Promise((resolve) => {
    const finish = (code: number) => {
      clearTimeout(timer);
      w.removeEventListener("message", onMsg);
      if (cancel === stop) cancel = null;
      resolve(code);
    };
    const stop = () => { on.err("^C stopped"); finish(130); };
    const onMsg = ({ data }: MessageEvent) => {
      if (data.id !== id) return;
      if (data.type === "out") on.out(data.s);
      else if (data.type === "err") on.err(data.s);
      else if (data.type === "files") on.files(data.files);
      else if (data.type === "done") finish(data.code ?? 0);
    };
    const timer = setTimeout(() => { on.err(`timed out after ${timeoutMs / 1000}s`); killPy(); }, timeoutMs);
    cancel = stop;
    w.addEventListener("message", onMsg);
    w.addEventListener("error", (e) => { on.err(e.message || "worker error"); finish(1); }, { once: true });
    w.postMessage({ id, type: "pkgs" in job ? "pip" : "run", ...job });
  });
}
