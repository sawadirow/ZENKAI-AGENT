# ZENKAI

Chat with a team of AI agents that write, run, test and fix web apps and Python scripts — in the browser.

## Run locally

```sh
cp .env.example .env     # add GROQ_API_KEY and/or GEMINI_API_KEY
npm install              # or: bun install
npm run dev
```

`npm test` runs the unit tests, `npm run build` makes a production build.

## What's inside

| Screen | What it does |
| --- | --- |
| Chat | Describe an app; agents write files, run commands, test, and auto-fix errors |
| Workspace | File tree + editor + chat side by side (wide screens) |
| Preview | Live sandboxed preview of `index.html` / `style.css` / `script.js` |
| Shell | **Browser shell** (simulated: `ls cat touch rm mv echo node js test curl python py pip clear`, ↑/↓ history, Ctrl+C/Stop) and **Real Linux** (real bash in a Docker container via `terminal-server/`) |
| Files / Code / Settings | Manage files, edit code, reset style/chat/project |

Python runs in a Web Worker (Pyodide), so a runaway script never freezes the app and can be stopped.
`pip install` uses PyPI through micropip (pure-Python packages and Pyodide builds). Files a Python script
writes appear in the project automatically. `npm` isn't available in the browser — import packages as ESM from
`https://esm.sh/<package>`.

## Tools (Replit-style hub)

Bottom tabs: **Chat · Workspace · Preview · Shell · Tools**. Everything else lives in Tools, one screen per topic:

| Tool | Status |
| --- | --- |
| Secrets | Works. Keys stay on the device. The AI sees names only and asks for a missing key with an input bar in chat |
| Integrations | Works. Presets (OpenAI, Stripe, Supabase, GitHub, Telegram…) that save into Secrets |
| Agent Skills | Works. Standing instructions added to every AI request |
| Git | Local checkpoints (snapshot / restore / diff). Real git is in the Real Linux shell |
| Console · Workflows | Works. Run output; saved command sequences |
| Growth | Works. SEO audit of your page |
| Security Center | Works. Scans files for leaked keys and risky code |
| Publishing | Exports one shareable `index.html`. Hosting a public link still needs Cloudflare Pages / Netlify |
| Monitoring | Health of ZENKAI itself. Published-app metrics need your host's analytics |
| Developer · Library · Files · Settings | Works |
| Database · Users & Auth · App Storage | **Not connected** — need a backend. The panel explains the options and asks the AI to plan it |

Secrets are readable from Python (`os.environ["NAME"]`) and the shell (`printenv NAME`). Browser-only apps can't keep a secret private, so the AI is told to use only public keys there.

## Real Linux terminal

Run `terminal-server/` on a VPS (see its README), then add the `wss://` URL and token in **Settings**. Project files are copied into the container when you connect; **Sync back** pulls changed files into the project. This is remote code execution by design — read the security section of `terminal-server/README.md` first.

## Security notes

- AI keys stay on the server (`/api/chat`); they are never sent to the browser or into the APK.
- `/api/fetch` only reads public http(s) pages: private/loopback/metadata addresses are blocked, every redirect hop is re-checked, responses are size-capped.
- `/api/chat` and `/api/fetch` have a best-effort per-IP rate limit (in memory, per server instance). For a public launch, add a real limiter or login in front.
- Generated apps run in a sandboxed iframe; console messages are tagged with a per-run nonce so pages can't forge test results.

## Android

See [ANDROID.md](./ANDROID.md).
