# ZENKAI terminal server (real Linux)

Gives the app's **Shell → Real Linux** tab a real bash: each browser session runs in its own throw-away Docker
container (Ubuntu 24.04 with python3, pip, node, npm, git, gcc, curl…), streamed to the browser over WebSocket.

## Run it (on a Linux VPS you control)

```sh
docker build -f Dockerfile.sandbox -t zenkai-sandbox .   # once
npm install                                              # needs build tools for node-pty
TERMINAL_TOKEN=$(openssl rand -hex 24) ALLOWED_ORIGINS=https://your-app.example npm start
```

Put it behind HTTPS (Caddy/nginx → `wss://terminal.example.com`), because the app is served over https and
browsers block plain `ws://` from an https page. Then in the app: **Settings → Real Linux terminal** → paste the
`wss://` URL and the token.

## Settings (environment variables)

| Variable | Default | Meaning |
| --- | --- | --- |
| `TERMINAL_TOKEN` | required | shared secret, 16+ chars |
| `ALLOWED_ORIGINS` | any | comma list of allowed web origins |
| `MAX_SESSIONS` | 5 | simultaneous containers |
| `IDLE_MIN` / `MAX_MIN` | 15 / 120 | idle timeout / hard lifetime |
| `MEMORY` / `CPUS` | 512m / 1 | per-container limits |
| `NETWORK` | bridge | `none` = no internet inside containers |

## Security — read this

This is **remote code execution by design**. Containers drop all capabilities, run as an unprivileged user with
`no-new-privileges`, and have memory/CPU/PID limits, but Docker is not a perfect boundary. Run it on a
**dedicated, disposable VPS**, keep the token secret, don't mount anything sensitive, and don't expose it to
people you don't trust. `NETWORK=bridge` lets code reach the internet (and your VPS's local network from the
container) — firewall accordingly or use `none`.
