// ZENKAI terminal server: one throw-away Docker container per browser session, streamed over WebSocket.
// Run it on a VPS you control (it needs the Docker CLI + access to the Docker daemon). See README.md.
import { WebSocketServer } from "ws";
import pty from "node-pty";
import { execFile } from "node:child_process";
import { timingSafeEqual, randomBytes } from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const env = (k, d) => process.env[k] ?? d;
const TOKEN = env("TERMINAL_TOKEN", "");
if (TOKEN.length < 16) { console.error("Set TERMINAL_TOKEN to a random string of 16+ characters."); process.exit(1); }
const PORT = Number(env("PORT", "8787"));
const IMAGE = env("SANDBOX_IMAGE", "zenkai-sandbox");
const MAX_SESSIONS = Number(env("MAX_SESSIONS", "5"));
const IDLE_MS = Number(env("IDLE_MIN", "15")) * 60_000;
const MAX_MS = Number(env("MAX_MIN", "120")) * 60_000;
const MEM = env("MEMORY", "512m");
const CPUS = env("CPUS", "1");
const NETWORK = env("NETWORK", "bridge"); // use "none" to cut internet access (pip/npm/git then won't work)
const ORIGINS = env("ALLOWED_ORIGINS", "").split(",").map((s) => s.trim()).filter(Boolean);

const safeEq = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && timingSafeEqual(x, y); };
const sessions = new Set();

// Stays inside `root` no matter what name the browser sends.
const inside = (root, rel) => { const p = path.resolve(root, rel); return p === root || p.startsWith(root + path.sep) ? p : null; };

async function writeFiles(root, files) {
  let n = 0;
  for (const [name, text] of Object.entries(files ?? {})) {
    if (++n > 300 || typeof text !== "string" || text.length > 500_000) continue;
    const p = inside(root, name);
    if (!p || p === root) continue;
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.writeFile(p, text);
  }
}

async function readFiles(root) {
  const out = {};
  let count = 0;
  const walk = async (dir, depth) => {
    for (const e of await fs.readdir(dir, { withFileTypes: true })) {
      if (e.name === "node_modules" || e.name.startsWith(".")) continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory() && depth < 3) await walk(p, depth + 1);
      else if (e.isFile() && count < 200) {
        const st = await fs.stat(p);
        if (st.size > 200_000) continue;
        const buf = await fs.readFile(p);
        if (buf.includes(0)) continue; // binary
        out[path.relative(root, p)] = buf.toString("utf8");
        count++;
      }
    }
  };
  await walk(root, 0);
  return out;
}

const wss = new WebSocketServer({ port: PORT, maxPayload: 4_000_000 });
console.log(`terminal server on :${PORT}  image=${IMAGE}  network=${NETWORK}`);

wss.on("connection", async (ws, req) => {
  const url = new URL(req.url ?? "/", "http://x");
  const origin = req.headers.origin ?? "";
  if (ORIGINS.length && !ORIGINS.includes(origin)) return ws.close(4003, "origin not allowed");
  if (!safeEq(url.searchParams.get("token") ?? "", TOKEN)) return ws.close(4001, "bad token");
  if (sessions.size >= MAX_SESSIONS) return ws.close(4029, "server busy");

  const send = (o) => ws.readyState === ws.OPEN && ws.send(JSON.stringify(o));
  const id = randomBytes(6).toString("hex");
  const name = `zk-${id}`;
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), "zk-"));
  const cols = Math.min(Math.max(Number(url.searchParams.get("cols")) || 80, 20), 300);
  const rows = Math.min(Math.max(Number(url.searchParams.get("rows")) || 24, 5), 100);

  const args = ["run", "--rm", "-it", "--name", name,
    "--user", `${process.getuid()}:${process.getgid()}`,
    "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
    "--pids-limit", "256", "--memory", MEM, "--cpus", CPUS, "--network", NETWORK,
    "-v", `${dir}:/work`, "-w", "/work", "-e", "HOME=/work", "-e", "TERM=xterm-256color",
    IMAGE, "bash"];
  const term = pty.spawn("docker", args, { name: "xterm-256color", cols, rows, env: process.env });
  sessions.add(id);

  let idle, hard, closed = false;
  const cleanup = () => {
    if (closed) return;
    closed = true;
    clearTimeout(idle); clearTimeout(hard);
    sessions.delete(id);
    try { term.kill(); } catch {}
    execFile("docker", ["rm", "-f", name], () => fs.rm(dir, { recursive: true, force: true }).catch(() => {}));
    if (ws.readyState === ws.OPEN) ws.close();
  };
  const touch = () => { clearTimeout(idle); idle = setTimeout(() => { send({ t: "o", d: "\r\n[idle timeout]\r\n" }); cleanup(); }, IDLE_MS); };
  touch();
  hard = setTimeout(() => { send({ t: "o", d: "\r\n[session time limit]\r\n" }); cleanup(); }, MAX_MS);

  term.onData((d) => send({ t: "o", d }));
  term.onExit(({ exitCode }) => { send({ t: "exit", code: exitCode }); cleanup(); });
  ws.on("close", cleanup);
  ws.on("error", cleanup);

  ws.on("message", async (raw) => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    touch();
    try {
      if (m.t === "i" && typeof m.d === "string") term.write(m.d);
      else if (m.t === "r") term.resize(Math.min(Math.max(+m.c || 80, 20), 300), Math.min(Math.max(+m.r || 24, 5), 100));
      else if (m.t === "files") await writeFiles(dir, m.files);
      else if (m.t === "pull") send({ t: "files", files: await readFiles(dir) });
    } catch (e) { send({ t: "o", d: `\r\n[server error: ${e.message}]\r\n` }); }
  });
});
