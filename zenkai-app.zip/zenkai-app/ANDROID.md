# ZENKAI — Android app (Capacitor)

The APK is a thin shell around your **published** web app, because ZENKAI needs its server routes
(`/api/chat`, `/api/fetch`) to keep API keys off the device.

1. Publish the web app and note its URL (must be `https`).
2. Put that URL in `capacitor.config.json` → `server.url`.
3. Install Capacitor (once):
   ```sh
   npm install
   npm install @capacitor/core
   npm install -D @capacitor/cli @capacitor/android
   ```
4. Create and sync the Android project:
   ```sh
   npx cap add android
   npx cap sync android
   ```
5. Open Android Studio and build: `npx cap open android` → **Build › Build APK(s)**.
   (Needs Android Studio + JDK on your machine.)

Keys (`GROQ_API_KEY`, `GEMINI_API_KEY`) live on the server, never in the APK.
To test locally instead of using a published URL, run `npm run dev` and point `server.url` at your computer's
LAN address with `"cleartext": true` (development only — set it back to `false` for release).
