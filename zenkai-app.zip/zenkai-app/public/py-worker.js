// Python (Pyodide) runs here, off the main thread, so the UI never freezes.
// The app stops a runaway script by terminating this worker.
importScripts("https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js");

let py = null;
let booting = null;
const boot = async () => {
  py = await loadPyodide({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/" });
};

const HOME = "/home/pyodide";

onmessage = async ({ data }) => {
  const { id, type } = data;
  const post = (t, extra) => postMessage(Object.assign({ id, type: t }, extra || {}));
  try {
    if (!booting) booting = boot();
    await booting;
    py.setStdout({ batched: (s) => post("out", { s }) });
    py.setStderr({ batched: (s) => post("err", { s }) });

    if (type === "pip") {
      await py.loadPackage("micropip");
      await py.runPythonAsync("import micropip\nawait micropip.install(" + JSON.stringify(data.pkgs) + ")");
      post("out", { s: "✓ installed " + data.pkgs.join(" ") });
    } else {
      const files = data.files || {};
      for (const name of Object.keys(files)) {
        if (name.indexOf("/") === -1) py.FS.writeFile(HOME + "/" + name, files[name]);
      }
      py.FS.chdir(HOME);
      py.globals.set("_zk_env", JSON.stringify(data.env || {}));
      await py.runPythonAsync("import os, json\nos.environ.update(json.loads(_zk_env))");
      await py.loadPackagesFromImports(data.code);
      await py.runPythonAsync(data.code);

      // Send back any text files the script created or changed.
      const changed = {};
      for (const name of py.FS.readdir(HOME)) {
        if (name === "." || name === "..") continue;
        try {
          const st = py.FS.stat(HOME + "/" + name);
          if (!py.FS.isFile(st.mode) || st.size > 200000) continue;
          const text = py.FS.readFile(HOME + "/" + name, { encoding: "utf8" });
          if (files[name] !== text) changed[name] = text;
        } catch (e) { /* binary or unreadable */ }
      }
      post("files", { files: changed });
    }
    post("done", { code: 0 });
  } catch (e) {
    const msg = String((e && e.message) || e).split("\n").slice(-4).join("\n");
    post("err", { s: msg });
    post("done", { code: 1 });
  }
};
